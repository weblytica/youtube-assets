# Co-building: the stage-by-stage session script (shared by every workflow)

This is the heart of every build workflow in this skill. The scenario is created with one module and grown stage by stage (each workflow's `workflow.md` has its stage table), so the user watches it take shape in their own Make editor while you explain each piece. Every stage follows the same six beats. Don't merge stages to save time; the pacing is the product.

The documentation workflow reuses the Say, Rename, Note and Check in beats on a scenario that already exists.

## The six beats of every stage

1. **Say** (before touching Make): two to four sentences. What you're about to add, what it does for them, and the Make concept it introduces. Use the workflow's teaching lines (the stage table's Say column, and `module-walkthrough.md` where the workflow has one); adapt, don't read verbatim twice.
2. **Add**: build the stage file (the workflow's `build_blueprint.py --stage N …`) and push it (`scenarios_create` at stage 1, `scenarios_update` after). The new module arrives with Make's default label; earlier modules keep the names you gave them.
3. **Show**: reload the editor so the new module appears, then describe what they're looking at in one sentence ("Four circles now: the trigger, two API calls, and a new router").
4. **Note**: for each module the stage added, attach a note in Make that explains its purpose and how it relates to its neighbours. The text comes from the workflow's `build_blueprint.py --stage-notes N` (or the notes file you wrote, when documenting). Tell the user what you're doing: "I'm pinning a note to this module so the explanation lives inside Make, not just in this chat."
5. **Rename**: give each new module its short display name (same `--stage-notes` output, field `name`). Say why: "Default labels say what a module *is*; the name should say what it *does here*."
6. **Check in**: one line. Either a question that makes them look at the screen ("Hover the note badge next to the aggregator. That's the explanation we just wrote.") or "Say *next* when you're ready." Then wait. Never run two stages without a reply in between.

**Make the default reply easy to predict.** Some Claude apps suggest a reply in the chat entry field that the user can accept with the right arrow key. The app writes that suggestion, not you, so you cannot put text there directly. Help it guess right: ask your question in the final chat reply (not only in a mid-turn message), make it the last sentence, and name the expected short answer inside it ("Say *next* for Stage 6", "Reply *yes* and I'll click Run once"). Don't add a separate line with the default answer after the question.

Keep each stage's total text under roughly 150 words. If they ask a question, answer it, then return to the beat you were on.

## How notes and names actually work in Make (verified)

- **Names** live in the blueprint (`metadata.designer.name`). The build script writes them for every module of *earlier* stages, so each `scenarios_update` carries renames forward. The current stage's modules are left unnamed on purpose so the rename happens visibly in the editor. If a UI rename fails, the next stage's update applies the name anyway.
- **Notes** do **not** live in the blueprint. Make stores them separately; `metadata.notes` in a blueprint is ignored by the editor and dropped on save. Notes added in the editor (or through the REST notes endpoint) survive later `scenarios_update` calls. Verified on a throwaway scenario.
- So notes need one of two routes:
  - **Editor route (default, needs a browser tool):** right-click the module → **Add note** → type → **OK**, then **Ctrl+S** to save. A purple note badge appears at the module's top-left.
  - **API route (optional, needs `MAKE_API_TOKEN` in the environment):** `python3 <skill>/scripts/add_notes.py --zone <zone> --scenario-id <id> --notes <notes file> --blueprint <current blueprint> [--ids …]` (any workflow; feed it `--stage-notes N` output saved to a file; `--blueprint` drops notes for modules this scenario doesn't have). Unsubby also has its own `add_notes_api.py --stage N [--no-code-module]`. Never ask the user to paste the token into chat; if they have one, they set it as an environment variable themselves.
  - **Neither available:** say so once, skip the Note beat, and point out that every note's text is in the guide you'll hand them at the end.

## Showing progress and driving the editor

The Make editor does not refresh itself when the blueprint changes through the API. Someone has to reload the page after each update.

| Situation | How to show each stage |
|---|---|
| **Claude in Chrome** (`mcp__claude-in-chrome__*`) | Best. It's the user's own browser window. Use `browser_batch` to chain steps. |
| **Built-in browser** (tools ending in `Claude_Browser__*`, e.g. `mcp__Claude_Browser__*` or `mcp__remote-devices__Claude_Browser__*`) | Same calls; the user sees the pane inside the Claude app. Tell them they can also open the URL in their own browser and press F5 after each stage for full size. |
| **No browser tool** | Give the editor URL once. After each update say "Press F5 in the Make tab." For notes and renames, either use the API route or ask the user to do the right-click steps themselves while you dictate the text (slower, still a co-build). |

**Opening the editor (current Make UI):** `navigate` to `https://<zone>/<teamId>/scenarios/<scenarioId>/edit` lands on a read-only *Diagram* page with an **Edit** button top-right. Wait about 6 seconds for it to load, `find` the Edit button and click it, wait about 5 seconds, then screenshot at `scale` 0.5. If you click Edit before the page has loaded, nothing happens; just click again.

**Reloading after an update:** `navigate` to the same URL again, then Edit again. Save first (Ctrl+S) if you added notes or renamed anything; otherwise Chrome shows a **Leave site?** dialog and the navigation is blocked. If that dialog appears anyway, the unsaved work is yours (notes/renames), so cancel, press Ctrl+S, and navigate again.

**Finding a module to right-click:** take a screenshot. Modules sit left to right in template order at fixed designer x-positions (0, 300, 600, …), a router's routes stack vertically, and error handlers hang below the module they protect. Right-click the centre of the circle. The context menu has **Add note** and **Rename** under "Additional actions". If the menu doesn't show those items you clicked the canvas, not a module.

**Adding a note:** right-click → **Add note** → a small rich-text box opens above the module → click into it → `type` the note text → click **OK**. Then **Ctrl+S**. A toast says "The scenario was saved." The badge is a small purple square at the module's top-left; hovering it shows the note.

**Renaming:** right-click → **Rename** → select the existing name (Ctrl+A) → `type` the new name → press Enter or click OK → **Ctrl+S**.

**Editor quirks (verified October 2026):**
- **Click Edit by its `find` ref, never by coordinates.** The browser viewport can change size between screenshots, and a coordinate click can land on the **Active** toggle and switch the scenario on. If that happens, `scenarios_deactivate` at once and check `executions_list`.
- **The right-click menu can stick to the previously selected module.** After adding a note, close the note popup with its **X** before right-clicking the next module. If the menu still targets the wrong module, Ctrl+S and reload.
- **Note badges can hide behind route filter labels.** Zoom on the module or hover it to confirm the badge before moving on.
- **Run once can miss after a resize.** Before clicking it again, check `executions_list` so nothing runs twice.
- **`executions_get-detail` may return no module output.** Read the value from the module's output bubble in the editor instead.

**After each stage's notes and renames, one screenshot** to confirm badges and names. Don't try to read mapping panels from pixels; you already know what's in the blueprint.

Rules while showing:
- The user must not edit or save in the editor during the build. Say this once at stage 1, kindly.
- Don't dismiss Make dialogs about connections or scheduling; read them and relay what they say.
- If Make shows "This scenario has been modified elsewhere" on reload, load the latest.

## Fast path

Some users don't want the tour. If they say "just build it", or they've done this before, ask once: "Build it all at once, or walk through it step by step?" Respect the answer. For the fast path, build without `--stage` (every module arrives named), create in one call, open the editor once, add all notes (API route with the notes file plus `--blueprint` so only modules that exist get one, or the editor route module by module while narrating briefly), and still give a three-sentence summary of what's on screen. The guide at the end is produced either way.

## Mid-build changes

If the user asks to change something during a stage (a different query, recipient, time zone, or dropping a step), do it in the stage file via the script's flags, re-run `scenarios_update`, reload, and carry on. Changes to earlier stages are fine because every update sends the whole blueprint, and notes survive updates. Note what changed so the guide is accurate.
