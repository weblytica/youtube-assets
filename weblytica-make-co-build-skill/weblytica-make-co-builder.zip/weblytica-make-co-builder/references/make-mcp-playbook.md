# Make MCP playbook (shared)

Call order, verified behavior, and fallbacks that apply to every workflow. Each workflow's `workflow.md` adds its own apps, connection types, and gotchas. Tool names appear as `mcp__<server>__<tool>`; the server prefix varies per installation, so match on the suffix. Load deferred tools with one ToolSearch `select:` call listing everything you need.

## Before anything: is this the right Make account?

`environment_get` returns the zone, organizations, and teams the connection can reach. If the scenario or team the user names isn't there (for example they give a `us1.make.com` URL and the connection is on `us2.make.com`, or `scenarios_get` returns "Insufficient rights"), the Make MCP is connected to a different account. Stop and say so; the user reconnects the Make MCP with the right account. Don't guess IDs.

## Preflight (read-only)

1. `environment_get` → zone, organizationId, teams. More than one team → the user picks.
2. `scenarios_list` (teamId) → look for an existing scenario with the workflow's name. If found, offer to continue it instead of creating a duplicate, but check first: `scenarios_get` → is it **active** or on a real schedule, and does its module list match one of the workflow's stage files, or has the user edited it? Every stage update replaces the whole blueprint, so a live scenario would run half-built and the user's own edits would be lost. Tell the user what you found and get a yes; switch it to on-demand (or deactivate, with a yes) before any stage update.
3. Plan-dependent apps: `app-modules_list` shows `premiumApp` / `premiumTier` (1 = paid plans only). Check before building.

## Connections

1. `connection-requirements_get` (organizationId, teamId, every module the scenario will contain). A connection is usable only if it is under `existing` for every slot of that app. `existingInsufficientScopes` means it would fail; never use it.
2. Present usable connections by name; the user picks.
3. None usable:
   - **If `credential-requests_create` exists:** create a request for the app and modules, give the user the returned authorization URL, then `credential-requests_get` after they confirm.
   - **Otherwise** (common with scoped tokens): the user adds the connection at `https://<zone>/<teamId>/connections` → **Add**. Offer to open that page in the browser. Re-check afterwards.
4. Never ask for passwords, tokens, or API keys in chat.

## Build and create, stage by stage

1. **Stage 1:** build the stage file → `validate_blueprint_schema` → `validate_module_configuration` for new module types → optional `folders_create` → `scenarios_create` (teamId, folderId, blueprint, `scheduling: {"type": "on-demand"}`). Editor URL: `https://<zone>/<teamId>/scenarios/<scenarioId>/edit`.
2. **Later stages:** build → `scenarios_update` (scenarioId, the full stage blueprint) → reload the editor. `scenarios_update` replaces the whole blueprint; each stage file is the complete scenario so far, which is what you want.
3. If the user had to set something inside a module in the editor (an AI connection, a webhook), `scenarios_get` and carry that value into every later build, or your next update wipes it.
4. `validate_blueprint_schema` is structural only. A schema-valid blueprint can still fail on unknown modules or bad parameters; `validate_module_configuration` catches those.

## Reloading the editor

The editor doesn't pick up API changes on its own. `navigate` to the editor URL again after each update; that is a full reload. In the current Make UI the `/edit` URL opens a read-only Diagram page first; wait for it, then click **Edit**. If Make warns the scenario changed elsewhere, load the latest. Screenshot at `scale` about 0.5.

## Notes and names (verified October 2026)

- `metadata.designer.name` in the blueprint is the module's display name. It round-trips through `scenarios_create` / `scenarios_update` and shows in the editor.
- `metadata.notes` in the blueprint is stored by the API but **ignored by the editor** and dropped the next time the scenario is saved from the UI. Don't rely on it.
- Notes created in the editor (right-click → Add note → OK → Save) or through `POST /api/v2/scenarios/{id}/notes` persist across later `scenarios_update` calls. The MCP server has no notes tool: use the browser, or `scripts/add_notes.py` with `MAKE_API_TOKEN`.

## Test

1. `scenarios_run` (scenarioId) if the tool exists; otherwise **Run once** in the editor (browser or the user). Instant (webhook) scenarios: Run once puts the scenario in listening mode until data arrives.
2. `executions_list` → newest. Status: 1 success, 2 warnings, 3 error.
3. On 2 or 3: `executions_get-detail` → failing module id and message → the workflow's `troubleshooting.md`.
4. Fix: rebuild the full blueprint with adjusted flags, `scenarios_update`. **Ask before updating an active scenario, and before every re-run** (runs have real effects). If the scenario is active, also ask before `scenarios_deactivate`; for webhook scenarios, deactivating means incoming events queue until it is turned back on.

## Finalize

1. `scenarios_update` with the production scheduling: polling scenarios get `{"type": "daily", "time": "HH:MM"}` or an interval; instant scenarios get `{"type": "immediately"}`.
2. `scenarios_activate`. "Scenario is already running" = already active = success.
3. Labels (`scenario-labels_*`) only if the user asks.

## General gotchas

- **Scheduling is not in the blueprint.** Set it with `scenarios_create` / `scenarios_update`.
- **`metadata.zone`** should match the account's zone. The build scripts set it from `--zone`.
- **Big scenarios:** `scenarios_get` on a large scenario returns a saved file instead of inline JSON. Pass that file to the scripts; don't read it into the conversation.
- **On-demand first.** Create every scenario on-demand during a staged build; switch to the real schedule only after the test passes, so a half-built scenario never runs on its own.
- **Never renumber modules.** Mappings (`{{12.field}}`), aggregator `feeder` values, and search-result references (`{{3.__IMTLENGTH__}}`) all point at module IDs.
