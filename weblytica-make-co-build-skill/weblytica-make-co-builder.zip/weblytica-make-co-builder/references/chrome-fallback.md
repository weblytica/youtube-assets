# Browser fallback: building without the Make MCP server (any build workflow)

Use this when no Make MCP tools exist in the session but a browser tool does (Claude in Chrome `mcp__claude-in-chrome__*`, or the built-in browser, whose tools end in `Claude_Browser__*`). The user must already be signed in to Make in that browser. If they aren't, ask them to sign in first; never type their password.

The teaching layer is identical to the MCP path. Only the mechanics change: instead of API calls, you import a blueprint file and click. Prefer `read_page` / `find` over screenshots for reading state; use screenshots to confirm visual results like the module chain.

## 1. Build the blueprint file first

Same build script as the workflow, but you don't know connection IDs yet. Build with `0` for every connection (and webhook) ID so the file is complete, then fix connections in the editor. Examples:

```bash
# Unsubby
python workflows/unsubby/scripts/build_blueprint.py \
  --gmail-connection-id 0 --gmail-connection-label "Gmail" \
  --ai-connection-id 0 --ai-connection-label "Make's AI Provider" \
  --recipient <email> --zone <zone> --gmail-limit 5 [--no-code-module] --out unsubby.blueprint.json

# Calendly to Sheets: the spreadsheet must exist first (see the order below)
python workflows/calendly-sheets/scripts/build_blueprint.py \
  --sheets-connection-id 0 --calendly-connection-id 0 --hook-id 0 \
  --spreadsheet-id <id from the sheet URL> --timezone <IANA tz> --zone <zone> --out calendly.blueprint.json
```

**Calendly order:** connections (step 2) → create the spreadsheet (directly with a connected tool if one exists; otherwise build `--setup` with the real Sheets connection ID once step 2 gives it to you, import it as its own scenario, and Run once) → copy the spreadsheet ID from the sheet URL → build the main blueprint above → import (step 3).

Zone: read it from the Make URL in the address bar (`https://us1.make.com/...` → `us1.make.com`).

## 2. Create connections (user authenticates)

1. Navigate to `https://<zone>/<teamId>/connections` (or click **Connections** in the left sidebar).
2. Read the list. Each connection shows its account. If one exists for the right account, note its name.
3. If not: click **Add**, search the app (Gmail, Google Sheets, Calendly, …), click it, and hand control to the user: "Make will open the sign-in window. Sign in and allow every permission it asks for. Tell me when you're back on the Connections page." Do not interact with the sign-in window.
4. Unsubby's AI: click **Add**, search **Make AI**, pick **Make's AI Provider**, Save. No credentials needed.

## 3. Import the blueprint

1. Navigate to `https://<zone>/<teamId>/scenarios` → **Create a new scenario**.
2. In the editor, bottom toolbar, click the **three dots (More)** → **Import Blueprint** → **Choose file** → select the built JSON → **Save**. If the browser tool cannot upload files, ask the user to do just this click; tell them the exact path of the file.
3. Confirm the module chain appears (screenshot). Make will show red warnings on every module whose connection ID is `0`.

## 4. Assign connections in the editor

For each module with a warning:
1. Click the module.
2. In the **Connection** dropdown, choose the connection created in step 2. For the AI module, if no connection is listed, click **Add** → Make's AI Provider → Save.
3. For the AI module, open the **Model** dropdown and confirm `Large` (or any available model on Free) is selected.
4. Click **OK**.

Then **Save** the scenario (disk icon or Ctrl+S). Rename it by clicking the title at the top.

## 5. Test run

Follow the workflow's test phase, clicking instead of calling tools:
- **Unsubby:** confirm first (it archives up to 5 emails and sends one digest). Click **Run once** (bottom-left). If **Choose where to start** appears, pick **From now** (true test) or **All** (capped at 5). The user checks their inbox.
- **Calendly:** if the trigger shows no webhook, click it → **Create a webhook** → Calendly connection, events Invitee created and Invitee canceled → Save. Click **Run once** (it waits), the user books then cancels a test meeting, and you check the four tabs together.

Watch the bubbles above the modules: numbers are bundles processed. Click a bubble to inspect input and output. A red module is the error; read its message, then see the workflow's `troubleshooting.md`.

## 6. Finalize

1. **Unsubby:** trigger → **Limit** 500 → OK. Clock icon → **Every day** → time → OK. **Calendly:** nothing to schedule; instant triggers run as data arrives.
2. Turn the scheduling toggle ON. Save.
3. Export a copy for the user: three dots → **Export Blueprint**. Tell them where it downloaded.
4. **Names, notes, and the guide** are still part of done: rename and add a note to each module in the editor (`co-building.md`, editor route; text from the workflow's `--stage-notes N` or `module-notes.json`), save, then build the guide from the exported blueprint with the workflow's guide command.

## Reading state without MCP

- Scenario list and IDs: the URL after clicking a scenario is `/scenarios/<id>/edit`.
- Run history: **History** tab at the bottom of the editor; each row is an execution with status and operations used.
