# Module walkthrough and teaching lines

Each entry: the module as it appears in the blueprint, what it does in this scenario, the Make concept it introduces, and a **Teach** line you can say nearly verbatim. Keep the user's attention on the concept, not the JSON. Module IDs match the template so you can cross-reference execution errors.

## Concepts to introduce once, early

- **Scenario**: the whole automation, drawn left to right as circles (modules) joined by lines.
- **Module**: one action: "watch emails", "send an email", "run code".
- **Bundle**: one item flowing along the line. One email is one bundle.
- **Mapping**: pointing a module's field at something an earlier module produced. In the editor you drag a chip like `Subject` into a box; in the blueprint it reads `{{27.subject}}`, meaning "the subject from module 27".
- **Operation**: one module running once. Plans are priced per operation, so a scenario that does seven things to 100 emails costs about 700 operations.

## Flow in order

### [23] Gmail → Watch emails (`google-email:triggerWatchNewEmails`)
The **trigger**. Polls Gmail with the search `in:inbox AND category:social OR category:updates OR category:forums OR category:promotions`, up to 500 messages per run, full content, without marking them read.
**Teach:** "Every scenario starts with a trigger. This one asks Gmail: 'what's new in the Promotions, Social, Updates, and Forums tabs since I last looked?' and hands each email down the line as one bundle. By hand you'd add the Gmail app, pick Watch emails, choose your connection, and paste that search into the Query box."

Settings worth naming: *Filter type: Gmail filter* (so Gmail's own search syntax works), *Content format: Full* (we need the HTML body to find unsubscribe links), *Mark as read: No*.

### [26] Array aggregator (`builtin:BasicAggregator`, feeder 23)
Collects every email from one run into a single array. Filter on the way in: `{{23.id}}` exists (drops empty bundles when nothing is new).
**Teach:** "An aggregator is a funnel. 40 bundles come in, one bundle with a list of 40 goes out. We do this so the next step can sort the whole batch before working through it. The 'Source module' setting tells it where the batch began: the Gmail trigger."

### [27] Iterator (`builtin:BasicFeeder`)
Array: `sort(26.array; "categoryFolders.name")`. Splits the list back into one email at a time, now ordered by Gmail category.
**Teach:** "An iterator is the opposite of an aggregator: one list in, one bundle out per item. Sorting by category first means the digest groups Promotions together, Social together, and so on. Everything after this point happens once per email."

### [2] Text parser → Match pattern (`regexp:Parser`)
Pattern: `<a[^>]*\bhref="([^"]*unsubscribe[^"]*)"[^>]*>.*<\/a>` against `{{27.htmlBody}}`. Captures the first link whose URL contains "unsubscribe". *Continue when no match* is on, so emails without such a link still flow through.
**Teach:** "This is the heart of Unsubby. A regular expression is a search pattern; this one looks inside the email's HTML for a link whose address contains the word 'unsubscribe' and keeps just that address as `$1`. The setting 'continue even if no match' matters: without it, an email with no unsubscribe link would stop the whole run."

### [24] Iterator over labels (`builtin:BasicFeeder`)
Array: `{{27.userLabelFolders}}`. One bundle per user-created label on the email.

### [25] Text aggregator (`util:TextAggregator`, feeder 24)
Joins label names with `, `, skipping `UNREAD`.
**Teach (24 + 25 together):** "A small iterator/aggregator pair. Gmail gives us the email's labels as a list; we spin them out and glue them back together as 'Label A, Label B' so the digest can show them next to the subject. Same two tools as before, used on a smaller list."

### [34] Code → Run code (`code:ExecuteCode`, JavaScript) with error handler [35] Ignore
Input `text` = `stripHTML(27.htmlBody)`. Strips HTML entities, zero-width characters, leftover tags, emoji, and extra whitespace. Returns the cleaned text as `result`. The **Ignore** error handler lets the run continue if the code throws.
**Teach:** "Newsletters are messy. This module runs a few lines of JavaScript to clean the text before the AI reads it, which makes summaries better and cheaper. The little path hanging off it is an error handler set to Ignore: if cleaning fails for one odd email, we skip the cleaning and keep going instead of stopping the digest. Error handlers are how Make scenarios survive bad data."
*Paid plans only.* With `--no-code-module` this module is removed and the AI reads `stripHTML(27.htmlBody)` directly. Say so plainly: "Your plan doesn't include the Code app, so we're skipping the extra cleanup. The AI still gets readable text."

### [20] Make AI Toolkit → Simple Text Prompt (`ai-tools:Ask`, model `large`)
Prompt asks for a summary of 190 characters or fewer, in complete sentences, focused on intent and required action, given sender name, email, subject, and the first 650 characters of cleaned text. Output is `answer`.
**Teach:** "Make has a built-in AI module that uses Make's own AI Provider connection, so there's no OpenAI key to manage. We ask for one tight sentence per newsletter. Notice we only send the first 650 characters; AI cost scales with text length, and the opening of a newsletter is where the point is."

### [31] Gmail → Update email labels (`google-email:updateEmailLabels`)
Message ID `{{27.id}}`, remove label `INBOX`.
**Teach:** "Removing the INBOX label is how Gmail archives. The newsletter is not deleted; it leaves your inbox and lives in All Mail with its link in the digest. This is what makes your inbox quiet."

### [3] Text aggregator (`util:TextAggregator`, feeder 26, group by `{{27.fromName}}`)
Builds one HTML `<div>` per email: a star if Gmail marked it Important, the category and a link to the message in Gmail, the labels from [25], the AI summary from [20], and the "Unsubscribe from This Newsletter" link from [2] if one was found. Rows are grouped by sender name; Make exposes the group's key as `__IMTKEY__`.
**Teach:** "Now we fold everything back together. This aggregator writes a little block of HTML for each email, and its 'Group by' setting means it produces one bundle per sender instead of one giant blob. Grouping is what lets the digest show 'Sender: Acme' with all of Acme's emails under it."

### [10] Router (`builtin:BasicRouter`)
Two routes, run in order.
**Teach:** "A router is a fork. Both branches receive the same bundles; the top branch runs first for every bundle, then the bottom branch. We use that ordering trick: the first branch builds the table of contents and saves it, the second builds the body, fetches the table of contents, and sends."

### Route 1: [11] Text aggregator (feeder 3) → [12] Set variables
[11] joins `<p>{{3.__IMTKEY__}}</p>` per sender. [12] stores it as variable `TopLinks` with lifetime *One cycle*.
**Teach:** "Variables are Make's scratchpad for passing a value sideways across a router. 'One cycle' means it lives for this run only."

### Route 2: [5] Text aggregator (feeder 3) → [13] Get variables → [28] Gmail: Send an email
[5] writes `<p id="sender"><strong>Sender:</strong> name</p>` plus that sender's blocks. [13] reads `TopLinks`. [28] sends raw HTML to the recipient with subject `{{formatDate(now; "MMM D, YYYY")}} Unsubby Management Digest`.
**Teach:** "Last stop: one email, to you, with the sender index on top, a line, then every newsletter grouped by sender with its summary and unsubscribe link. The subject uses `formatDate(now; ...)`, a Make function, so each day's digest is dated. Click any unsubscribe link in the digest and you're done with that sender for good."

## Scenario settings (metadata.scenario)
`maxErrors: 3`, `autoCommit: true`, `sequential: false`, `dlq: false`. Defaults; no need to explain unless asked. If asked what "incomplete executions" (dlq) means: Make can park a failed run for manual retry instead of discarding it; off here because a missed digest isn't worth a manual queue.

## Scheduling
Daily at the user's chosen time. **Teach:** "The clock on the trigger is the schedule. Daily at 7 AM means Make wakes the scenario once, Gmail returns everything new since yesterday's run, and you get one email. Between runs the scenario costs nothing."
