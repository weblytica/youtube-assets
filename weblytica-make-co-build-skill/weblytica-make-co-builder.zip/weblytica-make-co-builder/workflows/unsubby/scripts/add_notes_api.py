#!/usr/bin/env python3
"""Add module notes to a Make scenario through the Make REST API.

This is the OPTIONAL fast route for adding notes. It needs a Make API token in
the environment variable MAKE_API_TOKEN (the user creates one in Make under
Profile → API/MCP access; Claude never asks for the token value in chat and
never prints it). Without a token, add notes in the editor instead; see
../../../references/co-building.md.

Why an API script at all: Make keeps module notes outside the blueprint, so
scenarios_update cannot create them. The notes endpoint can:

  POST https://<zone>/api/v2/scenarios/<scenarioId>/notes
  body: {"moduleIds": [23], "content": "<p>...</p>", "isFilterNote": false, "metadata": {}}

Usage:
  MAKE_API_TOKEN=... python add_notes_api.py --zone us1.make.com --scenario-id 456 --stage 3
  MAKE_API_TOKEN=... python add_notes_api.py --zone us1.make.com --scenario-id 456 --all [--no-code-module]

Prints one line per note: "added 23" or "skipped 23 (already has a note)".
Re-running is safe: a module that already has a note is skipped.
"""
from __future__ import annotations

import argparse
import html
import json
import os
import sys
import urllib.error
import urllib.request
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from build_blueprint import LAST_STAGE, stage_notes  # noqa: E402


def api(zone: str, token: str, method: str, path: str, body: dict | None = None):
    req = urllib.request.Request(
        f"https://{zone}/api/v2{path}",
        data=json.dumps(body).encode("utf-8") if body is not None else None,
        method=method,
        headers={"Authorization": f"Token {token}", "Content-Type": "application/json"},
    )
    try:
        with urllib.request.urlopen(req, timeout=30) as r:
            return json.loads(r.read().decode("utf-8") or "{}")
    except urllib.error.HTTPError as e:
        detail = e.read().decode("utf-8", "replace")[:300]
        raise SystemExit(f"{method} {path} failed: HTTP {e.code} {detail}")


def existing_noted_modules(zone: str, token: str, scenario_id: int) -> set[int]:
    try:
        data = api(zone, token, "GET", f"/scenarios/{scenario_id}/notes")
    except SystemExit as e:
        # Without the list we can't tell which modules already have a note;
        # posting anyway could duplicate notes. Stop and use the editor route.
        raise SystemExit(f"Could not list existing notes, stopping to avoid duplicates: {e}. Add notes in the editor instead.")
    noted: set[int] = set()
    for n in data.get("scenarioNotes", data.get("notes", [])) or []:
        for mid in n.get("moduleIds", []) or []:
            noted.add(int(mid))
    return noted


def main() -> int:
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--zone", required=True)
    p.add_argument("--scenario-id", type=int, required=True)
    g = p.add_mutually_exclusive_group(required=True)
    g.add_argument("--stage", type=int)
    g.add_argument("--all", action="store_true")
    p.add_argument("--no-code-module", action="store_true")
    a = p.parse_args()

    token = os.environ.get("MAKE_API_TOKEN")
    if not token:
        raise SystemExit("MAKE_API_TOKEN is not set. Add notes in the editor instead (see co-building.md).")

    stages = [a.stage] if a.stage else list(range(1, LAST_STAGE + 1))
    noted = existing_noted_modules(a.zone, token, a.scenario_id)
    for st in stages:
        for n in stage_notes(st, a.no_code_module):
            if n["id"] in noted:
                print(f"skipped {n['id']} (already has a note)")
                continue
            content = "<p>" + html.escape(n["note"]) + "</p>"
            api(a.zone, token, "POST", f"/scenarios/{a.scenario_id}/notes",
                {"moduleIds": [n["id"]], "content": content, "isFilterNote": False, "metadata": {}})
            print(f"added {n['id']}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
