#!/usr/bin/env python3
"""Write the user's guide to their finished Unsubby Digest scenario, as Markdown.

Reads the final built blueprint (so names, IDs, query, limit and recipient are
the real ones) and the shared module notes, and writes a document the user can
keep. Claude presents this file as the closing artifact of the session.

Usage:
  python make_guide.py --blueprint unsubby-digest.blueprint.json \
      --scenario-url https://us1.make.com/123/scenarios/456/edit \
      --schedule "Every day at 07:00" \
      [--out Unsubby-Digest-Guide.md]

The contact block at the end is fixed; do not remove it.
"""
from __future__ import annotations

import argparse
import json
import sys
from datetime import date
from pathlib import Path

MODULE_NOTES = Path(__file__).resolve().parent.parent / "assets" / "module-notes.json"

CONTACT = """
---

For help with Make.com scenarios contact:
Andy O'Neil
andy@weblytica.com
https://weblytica.com
"""


def iter_modules(flow, depth=0, route_label=""):
    for m in flow:
        yield m, depth, route_label
        for i, r in enumerate(m.get("routes", []) or [], start=1):
            yield from iter_modules(r.get("flow", []), depth + 1, f"Route {i}")
        for e in m.get("onerror", []) or []:
            yield e, depth + 1, "Error handler"


def main() -> int:
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--blueprint", required=True)
    p.add_argument("--scenario-url", required=True)
    p.add_argument("--schedule", required=True, help='e.g. "Every day at 07:00"')
    p.add_argument("--out", default="Unsubby-Digest-Guide.md")
    a = p.parse_args()

    bp = json.loads(Path(a.blueprint).read_text(encoding="utf-8"))
    notes = {int(k): v for k, v in json.loads(MODULE_NOTES.read_text(encoding="utf-8"))["modules"].items()}

    trigger = bp["flow"][0]
    query = trigger["parameters"].get("q", "")
    limit = trigger["parameters"].get("limit", "")
    send = next((m for m, _, _ in iter_modules(bp["flow"]) if m["module"] == "google-email:sendAnEmail"), None)
    recipient = ", ".join(send["mapper"]["to"]) if send else "(not set)"
    has_code = any(m["id"] == 34 for m, _, _ in iter_modules(bp["flow"]))

    rows = []
    sections = []
    for m, depth, route in iter_modules(bp["flow"]):
        mid = m["id"]
        entry = notes.get(mid, {})
        name = m.get("metadata", {}).get("designer", {}).get("name") or entry.get("name") or m["module"]
        label = entry.get("label", m["module"])
        where = f" ({route})" if route else ""
        rows.append(f"| {mid} | {name} | {label}{where} |")
        note = entry.get("note", "No note recorded for this module.")
        if mid == 34 and not has_code:
            continue
        sections.append(f"### {name}  \nModule ID **{mid}** · {label}{where}\n\n{note}\n")

    today = date.today().strftime("%B %d, %Y")
    doc = f"""# {bp.get('name', 'Daily Unsubscribe Digest')}

Your guide to the scenario we built together on {today}.

**Open it in Make:** {a.scenario_url}

## What it does

Once a day, Make looks at the newsletter-style mail in your Gmail (Promotions, Social, Updates and Forums tabs), and for each message:

1. finds the newsletter's unsubscribe link,
2. writes a one-line AI summary,
3. archives the message out of your inbox,
4. and adds it to a single digest email, grouped by sender.

You get one email with every newsletter's summary and an **Unsubscribe from This Newsletter** link next to it. Click the link to leave that list for good.

## Your settings

| Setting | Value |
|---|---|
| Runs | {a.schedule} |
| Digest goes to | {recipient} |
| Gmail search | `{query}` |
| Max emails per run | {limit} |
| Text cleanup (Code module) | {"On" if has_code else "Off (not available on this plan; the AI reads the stripped email text directly)"} |

## Everyday use

- **Pause or resume:** open the scenario and use the on/off toggle at the top. Off means no digest and no inbox changes.
- **A digest didn't arrive:** open the scenario → **History**. If there's no run at the scheduled time, the scenario is off or your Make plan is out of operations. If a run shows an error, the red module is the one that failed.
- **Operations:** every module that runs costs one operation. Expect roughly 7 to 9 operations per newsletter, plus about 8 per run. One hundred newsletters a day is roughly 900 operations a day.
- **Change the Gmail search, the time, or the recipient:** ask Claude, or click the trigger (first module) for the search, the clock icon for the time, and the last module for the recipient.

## The modules at a glance

| ID | Name | Make module |
|---|---|---|
{chr(10).join(rows)}

The ID is the small number in the corner of each circle in the editor. Each module also carries a note in Make with the same explanation as below (hover the note badge next to the module).

## What each module does

{chr(10).join(sections)}
{CONTACT}"""

    Path(a.out).write_text(doc, encoding="utf-8")
    print(f"Wrote {a.out}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
