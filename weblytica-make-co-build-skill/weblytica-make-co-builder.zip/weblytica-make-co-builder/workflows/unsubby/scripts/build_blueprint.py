#!/usr/bin/env python3
"""Fill the Unsubby Digest blueprint template with one user's values.

Why a script: the template has the same connection ID in three places, a label
in four, and a recipient address buried 1,200 lines deep. Hand-editing JSON that
size is where typos (and broken scenarios) come from. This script does the
substitution deterministically and refuses to emit a blueprint that still has a
placeholder in it.

Usage (all values required unless noted):

  python build_blueprint.py \
      --gmail-connection-id 1234567 \
      --gmail-connection-label "My Gmail (me@example.com)" \
      --ai-connection-id 2345678 \
      --ai-connection-label "My Make AI Provider connection" \
      --recipient me@example.com \
      --zone us1.make.com \
      [--ai-model large] [--ai-model-label "Large (Paid plans only)"] \
      [--name "Daily Unsubscribe Digest"] \
      [--gmail-query "in:inbox AND category:promotions"] \
      [--gmail-limit 5]        # small for the first test run; 500 for production
      [--no-code-module]       # Free plans: drop the paid Code module, AI reads stripped HTML
      [--stage N]              # co-building: emit only the modules up to stage N (1-9)
      [--name-all]             # apply the display names to every module (default when no --stage)
      [--out blueprint.final.json]

  python build_blueprint.py --list-stages
      Prints the nine co-building stages: which modules each adds and its title.

  python build_blueprint.py --stage-notes N
      Prints, as JSON, the modules added at stage N with their display name,
      Make label, and the note text to add in the editor (or via the notes API).

  python build_blueprint.py --check blueprint.final.json
      Verifies a finished blueprint has no leftover placeholders and prints a
      short module summary. Exit code 0 = clean.

Display names and notes come from ../assets/module-notes.json.

Co-building stages exist so Claude can grow the scenario in the user's Make
editor a few modules at a time (scenarios_create at stage 1, scenarios_update for
each later stage) and narrate each addition. Every stage output is a complete,
self-consistent blueprint: no module references a module that isn't present yet.

Names and stages: with --stage N, display names (metadata.designer.name) are
applied to the modules of stages 1..N-1 only. The modules that stage N adds keep
Make's default label, so the "rename" step of the session happens visibly in the
editor and the next stage's update carries that name forward instead of
reverting it. Without --stage (or with --name-all) every module is named.

Notes are NOT written into the blueprint. Make stores module notes outside the
blueprint (verified: metadata.notes round-trips through the API but the editor
ignores it and drops it on save). Add notes in the editor or via the REST notes
endpoint; see ../../../references/co-building.md.

The template lives next to this script at ../assets/unsubby-digest.template.json.
"""
from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path

ASSETS = Path(__file__).resolve().parent.parent / "assets"
TEMPLATE = ASSETS / "unsubby-digest.template.json"
MODULE_NOTES = ASSETS / "module-notes.json"
PLACEHOLDER_RE = re.compile(r"__[A-Z][A-Z0-9_]*__")
# These two look like placeholders but are real Make syntax. Never touch them.
MAKE_SYNTAX = {"__IMTCONN__", "__IMTKEY__"}

DEFAULT_NAME = "Daily Unsubscribe Digest (Unsubby)"
DEFAULT_MODEL = "large"
DEFAULT_MODEL_LABEL = "Large (Paid plans only)"

ROUTER_ID = 10
CODE_MODULE_ID = 34
CODE_ERROR_HANDLER_ID = 35
AI_MODULE_ID = 20
CODE_RESULT_REF = "trim(34.result)"
NO_CODE_REPLACEMENT = "trim(stripHTML(27.htmlBody))"

# (stage number, title, top-level module ids added at this stage, router routes kept)
# Order matches the template's flow so every stage is a prefix of the full
# scenario, which is what keeps mapping references valid at each step.
STAGES = [
    (1, "The trigger: Gmail watches your newsletter tabs", [23], 0),
    (2, "Collect the batch, then loop one email at a time", [26, 27], 0),
    (3, "Find the unsubscribe link with a pattern match", [2], 0),
    (4, "Gather the email's labels into one line", [24, 25], 0),
    (5, "Clean the text and write a one-line AI summary", [34, 20], 0),
    (6, "Archive the newsletter (remove INBOX)", [31], 0),
    (7, "Write one HTML block per email, grouped by sender", [3], 0),
    (8, "Router, route 1: build the sender index and save it", [ROUTER_ID], 1),
    (9, "Router, route 2: build the body and send the digest", [], 2),
]
LAST_STAGE = STAGES[-1][0]
# Modules that are not top-level flow entries but belong to a stage.
STAGE_EXTRA_MODULES = {5: [CODE_ERROR_HANDLER_ID], 8: [11, 12], 9: [5, 13, 28]}


def load_module_notes() -> dict[int, dict]:
    data = json.loads(MODULE_NOTES.read_text(encoding="utf-8"))
    return {int(k): v for k, v in data["modules"].items()}


def stage_module_ids(stage: int) -> list[int]:
    """All module ids (top-level and nested) that stage `stage` adds."""
    ids: list[int] = []
    for n, _t, top, _r in STAGES:
        if n == stage:
            ids.extend(top)
    ids.extend(STAGE_EXTRA_MODULES.get(stage, []))
    return ids


def list_stages() -> None:
    for n, title, ids, routes in STAGES:
        adds = ", ".join(str(i) for i in stage_module_ids(n)) or "(none)"
        extra = f"; router routes kept: {routes}" if routes else ""
        print(f"Stage {n}: {title}\n         adds module(s) {adds}{extra}")


def stage_notes(stage: int, no_code: bool) -> list[dict]:
    notes = load_module_notes()
    out = []
    for mid in stage_module_ids(stage):
        if no_code and mid in (CODE_MODULE_ID, CODE_ERROR_HANDLER_ID):
            continue
        entry = notes.get(mid)
        if not entry:
            raise SystemExit(f"module {mid} has no entry in {MODULE_NOTES.name}")
        out.append({"id": mid, "name": entry["name"], "label": entry["label"], "note": entry["note"]})
    return out


def iter_modules(flow):
    for m in flow:
        yield m
        for r in m.get("routes", []) or []:
            yield from iter_modules(r.get("flow", []))
        yield from iter_modules(m.get("onerror", []) or [])


def all_module_ids(flow) -> set[int]:
    return {m["id"] for m in iter_modules(flow)}


REF_RE = re.compile(r"\{\{[^}]*?\b(\d+)\.")


def verify_references(bp: dict) -> None:
    """Fail if any mapping points at a module that isn't in this blueprint.

    Make would accept such a blueprint and then fail at run time with an empty
    value, which is exactly the kind of silent problem a staged build can
    introduce. Catching it here keeps every stage runnable.
    """
    present = all_module_ids(bp["flow"])
    text = json.dumps(bp, ensure_ascii=False)
    dangling = {int(n) for n in REF_RE.findall(text)} - present
    feeders = {m["parameters"].get("feeder") for m in iter_modules(bp["flow"]) if isinstance(m.get("parameters"), dict)}
    dangling |= {f for f in feeders if isinstance(f, int) and f not in present}
    if dangling:
        raise SystemExit(f"blueprint references modules that are not present: {sorted(dangling)}")


def apply_stage(bp: dict, stage: int) -> None:
    """Trim the full blueprint down to everything up to and including `stage`."""
    if not 1 <= stage <= LAST_STAGE:
        raise SystemExit(f"--stage must be between 1 and {LAST_STAGE}")
    keep: set[int] = set()
    routes_kept = 0
    for n, _title, ids, routes in STAGES:
        if n > stage:
            break
        keep.update(ids)
        routes_kept = max(routes_kept, routes)
    bp["flow"] = [m for m in bp["flow"] if m["id"] in keep]
    for m in bp["flow"]:
        if m["id"] == ROUTER_ID:
            m["routes"] = m["routes"][:routes_kept]
    missing = {n for n in keep if n not in {m["id"] for m in bp["flow"]}}
    missing.discard(CODE_MODULE_ID)  # legitimately absent with --no-code-module
    if missing:
        raise SystemExit(f"stage {stage} expected modules {sorted(missing)} in the template")


def apply_names(bp: dict, up_to_stage: int | None) -> None:
    """Set metadata.designer.name for modules of stages <= up_to_stage (all if None)."""
    notes = load_module_notes()
    if up_to_stage is None:
        allowed = None
    else:
        allowed = set()
        for n in range(1, up_to_stage + 1):
            allowed.update(stage_module_ids(n))
    for m in iter_modules(bp["flow"]):
        if allowed is not None and m["id"] not in allowed:
            continue
        entry = notes.get(m["id"])
        if not entry:
            continue
        m.setdefault("metadata", {}).setdefault("designer", {})["name"] = entry["name"]


def remove_code_module(bp: dict) -> None:
    """Drop the paid Code module and feed the AI the stripped HTML directly.

    The Code module only cleans text before the AI summary. Without it the AI
    prompt reads stripHTML(27.htmlBody), which is what the Code module received
    as input anyway. Summaries are slightly noisier; the digest is otherwise
    identical. The error-handler route attached to the Code module goes with it.
    """
    before = len(bp["flow"])
    bp["flow"] = [m for m in bp["flow"] if m["id"] != CODE_MODULE_ID]
    if len(bp["flow"]) != before - 1:
        raise SystemExit(f"expected exactly one module with id {CODE_MODULE_ID} in the top-level flow")
    ai = next(m for m in bp["flow"] if m["id"] == AI_MODULE_ID)
    prompt = ai["mapper"]["input"]
    if CODE_RESULT_REF not in prompt:
        raise SystemExit("AI prompt no longer references the Code module output; template changed?")
    ai["mapper"]["input"] = prompt.replace(CODE_RESULT_REF, NO_CODE_REPLACEMENT)


def leftover_placeholders(text: str) -> set[str]:
    return {m for m in PLACEHOLDER_RE.findall(text) if m not in MAKE_SYNTAX}


def summarize(bp: dict) -> list[str]:
    lines = []

    def walk(flow, depth=0):
        for mod in flow:
            pad = "  " * depth
            name = mod.get("metadata", {}).get("designer", {}).get("name")
            shown = f'  "{name}"' if name else ""
            lines.append(f"{pad}[{mod['id']}] {mod['module']} v{mod['version']}{shown}")
            for route in mod.get("routes", []) or []:
                lines.append(f"{pad}  route:")
                walk(route.get("flow", []), depth + 2)
            for err in mod.get("onerror", []) or []:
                ename = err.get("metadata", {}).get("designer", {}).get("name")
                lines.append(f"{pad}  onerror: [{err['id']}] {err['module']}" + (f'  "{ename}"' if ename else ""))

    walk(bp["flow"])
    return lines


def check(path: Path) -> int:
    text = path.read_text(encoding="utf-8")
    bp = json.loads(text)
    left = leftover_placeholders(text)
    print(f"Scenario name: {bp.get('name')}")
    print("Modules:")
    for line in summarize(bp):
        print("  " + line)
    if left:
        print("\nFAIL: placeholders still present: " + ", ".join(sorted(left)))
        return 1
    print("\nOK: no placeholders left. Ready for scenarios_create / import.")
    return 0


def build(args: argparse.Namespace) -> int:
    text = TEMPLATE.read_text(encoding="utf-8")

    # Numeric fields: the template stores them as quoted placeholders so the
    # template is valid JSON; replace WITH the quotes so the output is a number,
    # which is what Make expects for connection IDs.
    text = text.replace('"__GMAIL_CONNECTION_ID__"', str(int(args.gmail_connection_id)))
    text = text.replace('"__AI_CONNECTION_ID__"', str(int(args.ai_connection_id)))

    def s(v: str) -> str:
        # JSON-escape a string value and strip the surrounding quotes that
        # json.dumps adds, because the placeholder already sits inside quotes.
        return json.dumps(v, ensure_ascii=False)[1:-1]

    text = text.replace("__GMAIL_CONNECTION_LABEL__", s(args.gmail_connection_label))
    text = text.replace("__AI_CONNECTION_LABEL__", s(args.ai_connection_label))
    text = text.replace("__AI_MODEL_LABEL__", s(args.ai_model_label))
    text = text.replace("__AI_MODEL__", s(args.ai_model))
    text = text.replace("__RECIPIENT_EMAIL__", s(args.recipient))
    text = text.replace("__SCENARIO_NAME__", s(args.name))
    text = text.replace("__ZONE__", s(args.zone))

    bp = json.loads(text)  # proves the result is still valid JSON
    bp["metadata"].pop("notes", None)  # notes never go in the blueprint (see module docstring)

    trigger = bp["flow"][0]
    assert trigger["module"] == "google-email:triggerWatchNewEmails"
    if args.gmail_query:
        trigger["parameters"]["q"] = args.gmail_query
    if args.gmail_limit is not None:
        limit = int(args.gmail_limit)
        if not 1 <= limit <= 500:
            raise SystemExit("--gmail-limit must be between 1 and 500 (Gmail's per-run maximum)")
        trigger["parameters"]["limit"] = limit

    if args.no_code_module:
        remove_code_module(bp)

    if args.stage is not None:
        apply_stage(bp, int(args.stage))
        apply_names(bp, None if args.name_all else int(args.stage) - 1)
    else:
        apply_names(bp, None)
    verify_references(bp)

    out = Path(args.out)
    out.write_text(json.dumps(bp, indent=2, ensure_ascii=False), encoding="utf-8")
    print(f"Wrote {out}")
    return check(out)


def main() -> int:
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--check", metavar="BLUEPRINT", help="only verify a finished blueprint")
    p.add_argument("--list-stages", action="store_true", help="print the co-building stages and exit")
    p.add_argument("--stage-notes", type=int, metavar="N", help="print the names and notes for the modules stage N adds, as JSON")
    p.add_argument("--stage", type=int, help=f"emit only modules up to this co-building stage (1-{LAST_STAGE})")
    p.add_argument("--name-all", action="store_true", help="with --stage: name every module, including the ones this stage adds")
    p.add_argument("--gmail-connection-id")
    p.add_argument("--gmail-connection-label")
    p.add_argument("--ai-connection-id")
    p.add_argument("--ai-connection-label")
    p.add_argument("--ai-model", default=DEFAULT_MODEL)
    p.add_argument("--ai-model-label", default=DEFAULT_MODEL_LABEL)
    p.add_argument("--recipient")
    p.add_argument("--zone", help="Make zone, e.g. us1.make.com or eu1.make.com (from environment_get)")
    p.add_argument("--name", default=DEFAULT_NAME)
    p.add_argument("--gmail-query", help="override the Gmail search query of the trigger")
    p.add_argument("--gmail-limit", help="max emails per run (1-500). Use 5 for the test run, 500 for production")
    p.add_argument("--no-code-module", action="store_true",
                   help="remove the paid Code module (Free plans); the AI reads stripHTML(htmlBody) directly")
    p.add_argument("--out", default="unsubby-digest.blueprint.json")
    args = p.parse_args()

    if args.list_stages:
        list_stages()
        return 0
    if args.stage_notes is not None:
        print(json.dumps(stage_notes(args.stage_notes, args.no_code_module), indent=2, ensure_ascii=False))
        return 0
    if args.check:
        return check(Path(args.check))

    missing = [
        n for n in ("gmail_connection_id", "gmail_connection_label", "ai_connection_id",
                    "ai_connection_label", "recipient", "zone")
        if not getattr(args, n)
    ]
    if missing:
        p.error("missing: " + ", ".join("--" + m.replace("_", "-") for m in missing))
    return build(args)


if __name__ == "__main__":
    sys.exit(main())
