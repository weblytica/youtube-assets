# Workflow: Unsubby, the Daily Unsubscribe Digest

The original co-build. Make watches Gmail's Promotions, Social, Updates and Forums tabs, grabs each newsletter's unsubscribe link, writes a one-line AI summary, archives the email, and sends one digest per day grouped by sender. Built in nine stages; the user watches each stage appear in their Make editor.

Read `../../references/co-building.md` before stage 1 (the six beats and editor mechanics), and `module-walkthrough.md` for the teaching line of every module. Files in this folder:

- `assets/unsubby-digest.template.json`, `assets/module-notes.json`
- `scripts/build_blueprint.py` (`--stage N`, `--stage-notes N`, `--list-stages`, `--check`, `--no-code-module`), `scripts/add_notes_api.py` (optional notes via API), `scripts/make_guide.py` (the closing guide, tailored to Unsubby)
- `module-walkthrough.md`, `troubleshooting.md`

## What gets built

```
Gmail: Watch emails (Promotions/Social/Updates/Forums)
  → Array aggregator (collect the batch)
  → Iterator (one email at a time, sorted by Gmail category)
      → Regex: find the unsubscribe link in the HTML
      → Iterator over the email's labels → Text aggregator (label list)
      → Code: clean the email text  [paid plans; skipped on Free]
      → Make AI Toolkit: 190-character summary
      → Gmail: remove INBOX label (archive)
      → Text aggregator: one HTML block per email, grouped by sender
  → Router
      ├─ Route 1: build the sender index → Set variable "TopLinks"
      └─ Route 2: build the body → Get variable → Gmail: send the digest
```

Template: `assets/unsubby-digest.template.json`. Names and notes for every module: `assets/module-notes.json`. Scripts:

- `scripts/build_blueprint.py`: fills the template. `--stage N` emits the scenario up to stage N with earlier stages' modules already named; `--stage-notes N` prints the new modules' names and note text; `--list-stages` shows the plan. It checks that no mapping points at a module that isn't there yet and refuses to emit a file with a placeholder left in it. Never hand-edit the template.
- `scripts/add_notes_api.py`: optional. Adds notes through Make's REST notes endpoint when the user has `MAKE_API_TOKEN` set. Otherwise notes are added in the editor.
- `scripts/make_guide.py`: writes the closing Markdown guide from the final blueprint.

## Phase 0: Preflight (read-only, two or three minutes)

1. Check which tools you have (the Tools table in SKILL.md). Decide your **Show** method now and tell the user how they'll watch: "I'll reload your Make tab after each step" or "I'll ask you to press F5 after each step".
2. `environment_get` → zone, organization, teams. More than one team → ask which.
3. Read `../../references/co-building.md` and `module-walkthrough.md`.
4. Set expectations in five lines or fewer: what the finished scenario does each morning, that it takes nine short steps, that they'll watch it appear, and that the only thing they may be asked to do in Make is sign in. Then ask the four setup questions in **one** message:
   - Which Gmail account to watch?
   - Where to send the digest? Default: same address.
   - What time each day? Default: 7:00 AM in their Make organization's timezone.
   - Which Gmail tabs? Default: Promotions, Social, Updates, Forums.
5. Offer the choice once: "Walk through it in nine short steps (recommended), or build it all at once?" Default to the walkthrough.

## Phase 1: Plan check

`app-modules_list` for `code` v1 → `premiumTier`. The Code module needs a paid plan. On Free, build every stage with `--no-code-module` and say in one sentence that the AI will read the stripped email text directly.

The AI model `large` is labeled "Paid plans only" and cannot be validated over MCP. Build with it anyway; if the test run fails on module 20 with a model error, ask the user to open that module in Make, pick an available model, save, and then `scenarios_get` to pick up the value.

## Phase 2: Connections (the one place the user touches Make)

Teach first: a connection is a saved login that Make keeps so the scenario can act as the user. Scenarios hold a connection ID, not a password.

1. `connections_list` (team, `type: ["google-email", "ai-provider"]`). Gmail's type is `google-email`, not `google`.
2. **Gmail.** `connection-requirements_get` with the three Gmail modules (`triggerWatchNewEmails`, `updateEmailLabels`, `sendAnEmail`; app `google-email` v4). A connection is usable only if it appears under `existing` for all three; `existingInsufficientScopes` means it lacks send or modify and must not be used.
   - Present every usable connection by name and email, plus "create a new one". Let the user pick; never auto-pick.
   - None usable: if `credential-requests_create` exists, use it (type `google-email`, scopes readonly/modify/send), hand over the authorization URL, wait, then `credential-requests_get`. Otherwise send them to Make → **Connections** → **Add** → **Gmail** → sign in → allow all permissions; offer to open that page in the browser. When they say done, re-list and re-check.
3. **AI.** Prefer **Make's AI Provider** (`ai-provider`, no key). Missing: user adds it at Connections → Add → "Make AI" → Make's AI Provider → Save; if it isn't offered there, it gets created from inside the module at stage 5. Their own OpenAI/Anthropic connection also works, but `--ai-model` must then be a provider model ID, not `large`.
4. Check in: name the two connections you'll use.

## Phase 3: Build in stages (the session)

Follow `../../references/co-building.md` exactly. In outline, every stage is Say → Add → Show → Note → Rename → Check in:

- **Command form:** `python3 <skill>/workflows/unsubby/scripts/build_blueprint.py --stage N --gmail-connection-id … --gmail-connection-label "…" --ai-connection-id … --ai-connection-label "…" --recipient … --zone … --gmail-limit 5 [--no-code-module] --out <scratch>/unsubby-stage-N.json`.
- **AI connection not created yet?** Pass `--ai-connection-id 0 --ai-connection-label pending` for stages 1 to 4 (module 20 doesn't exist yet). At stage 5, pass the real ID, or create the scenario with 0 and have the user add the connection inside module 20 (see below).
- **Values set in the editor are carried forward.** Whenever the user changes something inside a module (AI connection, AI model), `scenarios_get` and pass those values on every later build: `--ai-connection-id`, and `--ai-model` / `--ai-model-label` (the script otherwise resets the model to `large`).
- **Stage 1** `build_blueprint.py --stage 1 --gmail-limit 5 …` → `validate_blueprint_schema` → `scenarios_create` with `scheduling: {"type":"on-demand"}` and the optional "Unsubby" folder → open `https://<zone>/<teamId>/scenarios/<id>/edit` in the browser, click **Edit** → Say / Show → add the note and rename module 23 in the editor, Ctrl+S → Check in.
- **Stages 2 to 9** `build_blueprint.py --stage N …` → `scenarios_update` with the **full** stage blueprint → reload the editor and click Edit → Say / Show → for each new module: note, then rename (`--stage-notes N` gives the text) → Ctrl+S → Check in.
- Notes: editor route by default (right-click → Add note → type → OK). API route if `MAKE_API_TOKEN` is set: `python3 <skill>/workflows/unsubby/scripts/add_notes_api.py --zone <zone> --scenario-id <id> --stage N [--no-code-module]` (always pass `--no-code-module` on Free, or it posts notes to modules that don't exist). Neither: skip the beat, say so once, the guide carries the text.
- Stage 5 on a plan without the AI connection: pause here for the user to add it inside the module, then `scenarios_get` and continue from that blueprint.
- `validate_module_configuration` for the Gmail modules at the stage they appear (1, 6, 9). Skip the AI module; its model lookup always fails over MCP.

Keep each stage under about 150 words of your own text. The teaching lines are in the walkthrough; the on-screen cues and the note/rename mechanics are in `co-building.md`.

## Phase 4: Test run

Teach: a run is one pass; each module execution is one **operation**; plans are priced in operations. This scenario costs roughly seven operations per email.

1. Confirm: "This will archive up to 5 newsletters and send you one digest. Run it?"
2. `scenarios_run` if present; otherwise the user presses **Run once** (bottom-left), or you click it in the browser. If **Choose where to start** appears: **From now** for a true test, **All** to process what's already there (capped at 5).
3. Watch together: in the editor, bubbles above each module show bundle counts. Point them out. Then `executions_list`; status 1 success, 2 warnings, 3 error. Anything but 1 → `executions_get-detail` before changing anything → `troubleshooting.md`.
4. Fix cycle: adjust flags, rebuild (no `--stage`), `scenarios_update`, then **ask again before running**: every run archives real emails and sends a digest.
5. The user confirms the digest arrived and reads right. That is the test passing.

## Phase 5: Make it real

1. Rebuild with `--gmail-limit 500` (plus any values carried forward from the editor, such as `--ai-model`), `scenarios_update`. Explain why the limit was 5.
2. `scenarios_update` with `scheduling: {"type":"daily","time":"HH:MM"}`.
3. `scenarios_activate` ("already running" = success). Reload the editor so they see the toggle on.
4. **The guide.** Run `python3 <skill>/workflows/unsubby/scripts/make_guide.py --blueprint <final blueprint> --scenario-url <editor URL> --schedule "Every day at HH:MM" --out <scratch>/Unsubby-Digest-Guide.md`. It lists every module with its name and ID, explains each one's purpose and how it connects to its neighbours (same text as the notes in Make), records their settings, and ends with Andy's contact block. Deliver it as an artifact: use `SendUserFile` or `present_files` if available, otherwise the `Artifact` tool, otherwise tell them the file path. Don't paraphrase the guide in chat; hand it over.
5. Final message, short: name and link, when it runs, what arrives, how to pause it (the toggle), where to look if a digest is missing (**History** tab), that the guide is attached, one line offering changes later, and the closing hand-off line from SKILL.md.

## The stages (co-building table)

Module numbers match the template; the editor shows them in each circle's corner. Names and notes per stage: `python3 <skill>/workflows/unsubby/scripts/build_blueprint.py --stage-notes N [--no-code-module]`.

| Stage | Adds (ID: new name) | Say (anchor idea) | Show (what they'll see) | Check in |
|---|---|---|---|---|
| 1 | 23: Watch newsletter tabs | Every scenario starts with a trigger. This one asks Gmail for new mail in four tabs. Connection = saved login. | One red Gmail circle with a clock badge (the schedule). | "Click the circle. The Query box has the Gmail search. Recognize the `category:` words?" |
| 2 | 26: Collect all emails · 27: One email at a time (sorted) | Collect the batch, sort by category, then hand out one email at a time. Aggregator = funnel; iterator = the opposite. | Three circles. | "Say *next*." |
| 3 | 2: Find unsubscribe link | The Unsubby trick: a pattern that finds a link whose address contains 'unsubscribe'. 'Continue when no match' keeps the run alive. | Four circles. | "Want to see the pattern? Click the parser." |
| 4 | 24: Split labels · 25: Join labels | Same two tools on a smaller list: the email's labels, joined with commas. | Six circles. | "Notice the second aggregator joins with ', '. Say *next*." |
| 5 | 34: Clean email text · 35: Ignore cleanup errors · 20: AI one-line summary | Clean the text in JavaScript, then ask Make's AI for a 190-character summary. The dangling path is an error handler set to Ignore. (Free plan: 34 and 35 are skipped; say so.) | Eight circles, one with a side branch. | "Click the AI module and read the prompt. Would you change any wording? We can." |
| 6 | 31: Archive (remove INBOX) | Removing INBOX is how Gmail archives. Nothing is deleted. | Nine circles. | "This is the step that quiets your inbox. OK to keep it?" (If no, offer to delete module 31 and continue.) |
| 7 | 3: Build email block (by sender) | Fold everything into one HTML block per email, grouped by sender. | Ten circles. | "Say *next*." |
| 8 | 10: Split: index vs body · 11: Build sender index · 12: Save index (TopLinks) | A fork. Top branch builds the sender index and stores it in a variable for one cycle. | Router diamond with one branch. | "See the fork? Say *next* for the second branch." |
| 9 | 5: Build digest body · 13: Load index (TopLinks) · 28: Send the digest | Bottom branch builds the body, fetches the index, sends you the digest. Scenario complete. | Both branches, ending in the Gmail send module. | "That's the whole thing. Ready to run it once, limited to 5 emails?" |

After stage 9 the build is finished; continue with the test run, then limit, schedule, activate, and the guide (Phases 4 and 5 above).


## Make MCP details for this blueprint: verified facts (checked against Make's catalog, October 2026)

| Item | Value |
|---|---|
| Gmail app / version | `google-email` v4 |
| Gmail modules used | `triggerWatchNewEmails`, `updateEmailLabels`, `sendAnEmail` |
| Gmail connection type | `google-email` (filter `connections_list` with this, not `google`) |
| Gmail connection field | `parameters.__IMTCONN__` on modules 23, 31, 28 |
| Gmail scopes required (union) | `gmail.readonly`, `gmail.modify`, `gmail.send` |
| AI app / version | `ai-tools` v2, module `Ask` |
| AI connection field | `parameters.makeConnectionId` on module 20 (not `__IMTCONN__`) |
| AI connection types accepted | `ai-provider` (Make's AI Provider, no key), or `openai-gpt-3`, `anthropic-claude`, `gemini-ai-q9zyjp`, `mistral-ai`, `cohere`, `groq`, `amazon-bedrock`, Azure Foundry variants, `ai-agent-openai-compatible` |
| AI model with Make's AI Provider | `large` (labeled "Large (Paid plans only)" in the editor). Cannot be validated over MCP: `RpcGetModels` is blocked for org-bound tokens. |
| Code app | `code` v1, module `ExecuteCode`, `premiumApp: true`, `premiumTier: 1` (paid plans) |
| Other apps | `regexp` v1 `Parser`; `util` v1 `TextAggregator`, `SetVariables`, `GetVariables`; `builtin` `BasicAggregator`, `BasicFeeder`, `BasicRouter`, `Ignore` |
| Blueprint schema | Template passes `validate_blueprint_schema` as-is |
| Scheduling shape | `{"type": "daily", "time": "07:00"}` passes `validate_scheduling_schema` |

`connection-requirements_get` does **not** report a slot for `ai-tools:Ask`; use `extract_blueprint_components` or `connections_list` with `type: ["ai-provider"]` to find the AI connection.



### Gotchas specific to this blueprint

- **Aggregator `feeder` values are module ids** (26 feeds from 23; 25 from 24; 3 from 26; 11 and 5 from 3). Don't renumber modules.
- **Module 3 is fed by 26, not 27.** This is intentional: one aggregation per run, grouped by sender. Leave it.
- **`removeLabels: "INBOX"`** is a string, not an array, with restore mode `edit`. Make accepts it.
- **`__IMTKEY__`** is Make's group key output from an aggregator with `flags.groupBy`. It looks like a placeholder but isn't; the build script leaves it alone.
- **Scheduling is not in the blueprint.** UI exports omit it; you set it through `scenarios_create` / `scenarios_update`.
- **`metadata.zone`** should match the account's zone (`us1.make.com`, `eu1.make.com`, `eu2.make.com`, …). The script sets it from `--zone`.
- **The Gmail trigger's start point ("epoch")** cannot be set in the blueprint. A newly created scenario watches from its creation time. If the user wants older newsletters included in the first digest, they right-click the trigger → **Choose where to start** → pick a date or **All**, once.
- **On-demand first, daily later.** Creating with `daily` would let the scenario fire before the test run is checked, and during a staged build it would run a half-built scenario.
- **Stage files are prefixes.** Stage N contains every module of stages 1..N in template order. The script's reference check guarantees no mapping or `feeder` points at a module that isn't present yet, so each stage is runnable on its own (it just stops early).
