# Workflow: Document any Make scenario

Takes a scenario that already exists in the user's Make account (theirs, a client's, an old one nobody remembers) and leaves it documented:

1. every module has a short name that says what it does **here**,
2. every module carries a note in Make explaining its purpose and how it connects to its neighbours,
3. the user gets a Markdown guide listing every module, its name, purpose, settings, and connections.

This is the same documentation the build workflows produce, made standalone. It works on any scenario, any apps.

## The one rule that outranks everything

**Document, don't change.** Names and notes are the only edits. Never alter mappings, filters, connections, scheduling, or module order, even if something looks wrong. If you spot a problem (a filter that is always true, a hard-coded email address, a missing error handler, mixed connections), list it under **Things I noticed** in the guide and in chat, and offer to fix it as a separate task the user approves.

## Tools

Same as the build workflows (see SKILL.md): Make MCP for reading and renaming, a browser for showing the editor and pinning notes, `MAKE_API_TOKEN` optional for notes through the API. Read `../../references/co-building.md` for the editor mechanics (opening, reloading, right-click → Add note / Rename, saving).

For modules you don't recognise, look them up rather than guessing: `app-module_get` (instructions format) gives the label, purpose, inputs and outputs. For mapping syntax, filters, IML functions, aggregators, and error handlers, read the matching file in `../../vendor/make-skills/make-module-configuring/` and `../../vendor/make-skills/make-scenario-building/`.

## Phase 0: Find the scenario (read-only)

1. The user gives a scenario URL (`https://<zone>/<teamId>/scenarios/<id>/edit`), an ID, or a name. For a name: `environment_get`, then `scenarios_list` (team), and confirm the match.
2. `scenarios_get` (scenarioId). Big scenarios come back saved to a file; that's fine, don't read it into the conversation.
3. `python3 <skill>/scripts/outline_scenario.py --blueprint <file> --prefix <scratch>/<slug> --chunks 5`. This writes `<slug>.outline.md` (the module map) and `<slug>.notes.json` (the skeleton you fill), and prints the teaching chunks.
4. Read the outline. Look up every module whose label is shown as raw `app:module`.

## Phase 1: Agree the approach (one message)

Tell the user in two or three lines what the scenario does, as you understand it from the outline, and ask:

- **Names:** keep the names you already gave modules and only name the unnamed ones (default), or replace every name?
- **Notes:** add a note to every module (default). Notes aren't in the blueprint, so look first: open the editor and screenshot for note badges (purple squares at a module's top-left), or let `add_notes.py` list them on the API route. Modules that already have a note are skipped; Claude never deletes a note. If the user wants one replaced, they delete it themselves first.
- **Pace:** walk through it in chunks of about five modules, explaining each (recommended, and what makes it a lesson), or document it all at once?
- **Is it live?** Check `isActive` in the `scenarios_get` response itself (a raw blueprint file doesn't say). If it is active, renames go through the editor rather than a blueprint update, so nothing about the running scenario is touched. Say so.

## Phase 2: Write the names and notes

Fill `<slug>.notes.json`. For each module:

- **name**: at most about 30 characters. Says what it does in this scenario, not what kind of module it is. "Search Invitee", not "Google Sheets Search Rows". Routers get a question or a destination ("New or existing?", "Send to 4 tabs"). Error handlers say what they protect ("Skip bad phone numbers").
- **note**: two to four sentences. What it does, why it's there, and how it relates to the module before and after it. Name the data it uses from earlier modules in plain words ("the email from the trigger"). Start trigger notes with `TRIGGER.` and error handler notes with `ERROR HANDLER on <name>.` so they stand out. If a route has a filter, explain the filter in the note of the first module after it.
- **label**: leave as filled, or replace a raw `app:module` with the label Make shows ("Google Sheets: Search Rows").

Write all of them before touching Make, so the names are consistent across the scenario.

## Phase 3: Apply, chunk by chunk

For each chunk (or once, on the fast path), the beats are **Say → Rename → Note → Check in** (the build workflows' Add and Show beats don't apply; the modules already exist):

- **Say**: two to four sentences on what this part of the scenario does and the Make concept it shows. Use `co-building.md`'s teaching style.
- **Rename**, one of two routes:
  - *Editor route* (default; required for active scenarios unless the user says otherwise): right-click → Rename → type → Enter, for each module in the chunk, then Ctrl+S.
  - *Blueprint route* (inactive scenarios, with the user's yes): `python3 <skill>/scripts/apply_names.py --blueprint <file> --notes <scratch>/<slug>.notes.json --out <scratch>/named.json --only-unnamed [--ids <chunk ids>]` (drop `--only-unnamed` only if the user chose to replace every name). It refuses to write if anything other than names would change. Immediately before sending, `scenarios_get` again and re-run `apply_names.py` on the fresh copy, so an edit made in the meantime isn't overwritten. Then `scenarios_update` (scenarioId, blueprint from `named.json`). Reload the editor.
- **Note**: editor route (right-click → Add note → type → OK, then Ctrl+S) or API route: `MAKE_API_TOKEN=… python3 <skill>/scripts/add_notes.py --zone <zone> --scenario-id <id> --notes <scratch>/<slug>.notes.json --blueprint <file> --ids <chunk ids>`. Neither available: say so once; the guide carries every note.
- **Check in**: one line that points at the screen ("Hover the new badge on the router."), then wait.

## Phase 4: The guide

1. Write `<slug>-overview.md` for this scenario with these sections:
   - `## What it does`: three to six plain sentences or a short numbered list, written for the business owner, not a developer.
   - `## How it runs`: the trigger (instant webhook, schedule and interval, or on demand) from the scenario's scheduling, and what one run does.
   - `## Things I noticed`: every observation from "Document, don't change", each with why it matters and the suggested fix. Omit the section if there's nothing.
2. `scenarios_get` once more after the last rename (editor renames aren't in your local file) and use that fresh file: `python3 <skill>/scripts/make_guide.py --blueprint <fresh file> --notes <scratch>/<slug>.notes.json --scenario-url <editor URL> --overview-file <scratch>/<slug>-overview.md [--setting "Label=Value" ...] --out <scratch>/<Scenario-Name>-Guide.md`. Add settings that matter to the owner: connection names in use, spreadsheet or base links, recipients, schedule.
3. The script warns about any module without a note; fix those first.
4. Deliver the guide as a file (or artifact). Don't paraphrase it in chat.

## Finish

Short closing: how many modules were named and noted, where the guide is, the top item from Things I noticed (if any) with an offer to fix it, and the hand-off line from SKILL.md.

## Edge cases

- **Very large scenarios (40+ modules)**: chunk by route, not by count, and ask after every two or three chunks whether to keep the walkthrough or finish the rest quickly.
- **Shared or locked scenarios** (`islocked`, `isShared`): read-only; produce the guide and the notes file, apply nothing, and tell the user.
- **Modules in a sub-scenario or called scenario**: document each scenario separately; mention the link in both guides.
- **Notes the user wrote themselves**: never delete or overwrite them. Skip that module, and copy the user's note text into the notes file if they want it in the guide.
