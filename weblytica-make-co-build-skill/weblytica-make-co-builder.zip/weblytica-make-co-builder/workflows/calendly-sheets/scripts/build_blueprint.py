#!/usr/bin/env python3
"""Build the Calendly to Google Sheets scenario (and its one-time setup scenario).

Two blueprints come out of this script:

Claude prefers to create the spreadsheet DIRECTLY with a connected Google
Sheets/Drive tool, using --headers-json for the layout. The setup scenario
below is the fallback when no such tool is available.

1. The SETUP scenario (--setup). Two modules: Google Sheets "Create a Spreadsheet"
   with the four tabs, then a Sheets API call that writes the header row on every
   tab. Run it once; its output holds the new spreadsheet's ID and URL. This is how
   Claude creates the spreadsheet for the user without them typing anything.

2. The MAIN scenario. A Calendly webhook fires on every booking or cancellation;
   two Calendly API calls fetch the user and the meeting; a router sends the
   booking down four branches (Users, Event Types, Scheduled Events, Invitees),
   each doing "search the tab, then add or update". Built in six co-building stages.

Usage:

  python build_blueprint.py --setup --sheets-connection-id 123 --zone us1.make.com \
      [--title "Calendly Bookings"] [--out setup.blueprint.json]

  python build_blueprint.py \
      --sheets-connection-id 123 --calendly-connection-id 456 --hook-id 789 \
      --spreadsheet-id 1AbC... --timezone America/Chicago --zone us1.make.com \
      [--name "Calendly Bookings to Google Sheets"] \
      [--stage N]          # co-building: modules up to stage N (1-6)
      [--name-all]         # with --stage, also name the modules stage N adds
      [--out calendly-sheets.blueprint.json]

  python build_blueprint.py --list-stages
  python build_blueprint.py --stage-notes N      # JSON: modules stage N adds, with name/label/note
  python build_blueprint.py --headers            # the tab names and header rows, for checking
  python build_blueprint.py --headers-json       # {"title", "tabs": [{"name", "headers"}]} for creating the sheet directly
  python build_blueprint.py --check FILE         # leftover placeholders + module summary

Notes are never written into the blueprint (Make stores them separately). Pin them
in the editor or with ../../../scripts/add_notes.py; see references/co-building.md.
"""
from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path

ASSETS = Path(__file__).resolve().parent.parent / "assets"
TEMPLATE = ASSETS / "calendly-sheets.template.json"
MODULE_NOTES = ASSETS / "module-notes.json"
DATA_MODEL = ASSETS / "data-model.json"
PLACEHOLDER_RE = re.compile(r"__[A-Z][A-Z0-9_]*__")
MAKE_SYNTAX = {"__IMTCONN__", "__IMTHOOK__", "__IMTLENGTH__", "__ROW_NUMBER__", "__IMTKEY__"}

DEFAULT_NAME = "Calendly Bookings to Google Sheets"
MAIN_ROUTER_ID = 5

# (stage, title, top-level module ids added, main-router routes kept)
STAGES = [
    (1, "The trigger: Calendly tells Make the moment someone books", [23], 0),
    (2, "Fetch the details: who owns the calendar, and the meeting itself", [2, 4], 0),
    (3, "Router, branch 1: the Users tab (search, then add or update)", [MAIN_ROUTER_ID], 1),
    (4, "Branch 2: the Event Types tab", [], 2),
    (5, "Branch 3: the Scheduled Events tab", [], 3),
    (6, "Branch 4: the Invitees tab (with phone clean-up)", [], 4),
]
LAST_STAGE = STAGES[-1][0]
STAGE_EXTRA_MODULES = {3: [3, 6, 7, 8], 4: [9, 10, 11, 12], 5: [13, 14, 15, 16], 6: [17, 18, 22, 19, 20, 21]}


def load_notes() -> dict[int, dict]:
    return {int(k): v for k, v in json.loads(MODULE_NOTES.read_text(encoding="utf-8"))["modules"].items()}


def load_schema() -> dict:
    """Data model as tabs: [{"name", "headers"}] (Google Sheets view of data-model.json)."""
    dm = json.loads(DATA_MODEL.read_text(encoding="utf-8"))
    tabs = [{"name": e["name"], "headers": [f["header"] for f in e["fields"]]} for e in dm["entities"]]
    return {"spreadsheet_title": dm["spreadsheet_title"], "tabs": tabs}


def stage_module_ids(stage: int) -> list[int]:
    ids: list[int] = []
    for n, _t, top, _r in STAGES:
        if n == stage:
            ids.extend(top)
    ids.extend(STAGE_EXTRA_MODULES.get(stage, []))
    return ids


def iter_modules(flow):
    for m in flow:
        yield m
        for r in m.get("routes", []) or []:
            yield from iter_modules(r.get("flow", []))
        yield from iter_modules(m.get("onerror", []) or [])


REF_RE = re.compile(r"\{\{[^}]*?\b(\d+)\.")


def verify_references(bp: dict) -> None:
    present = {m["id"] for m in iter_modules(bp["flow"])}
    dangling = {int(n) for n in REF_RE.findall(json.dumps(bp, ensure_ascii=False))} - present
    if dangling:
        raise SystemExit(f"blueprint references modules that are not present: {sorted(dangling)}")


def verify_columns(bp: dict) -> None:
    """Every add/update row must map exactly as many columns as its tab has headers."""
    tabs = {t["name"]: len(t["headers"]) for t in load_schema()["tabs"]}
    for m in iter_modules(bp["flow"]):
        if m["module"] in ("google-sheets:addRow", "google-sheets:updateRow"):
            tab = m["mapper"]["sheetId"]
            n = len(m["mapper"]["values"])
            if tabs.get(tab) != n:
                raise SystemExit(f"module {m['id']} maps {n} columns but tab '{tab}' has {tabs.get(tab)} headers")


def apply_stage(bp: dict, stage: int) -> None:
    if not 1 <= stage <= LAST_STAGE:
        raise SystemExit(f"--stage must be between 1 and {LAST_STAGE}")
    keep: set[int] = set()
    routes = 0
    for n, _t, ids, r in STAGES:
        if n > stage:
            break
        keep.update(ids)
        routes = max(routes, r)
    bp["flow"] = [m for m in bp["flow"] if m["id"] in keep]
    for m in bp["flow"]:
        if m["id"] == MAIN_ROUTER_ID:
            m["routes"] = m["routes"][:routes]


def apply_names(bp: dict, up_to_stage: int | None) -> None:
    notes = load_notes()
    allowed = None
    if up_to_stage is not None:
        allowed = {i for n in range(1, up_to_stage + 1) for i in stage_module_ids(n)}
    for m in iter_modules(bp["flow"]):
        if allowed is not None and m["id"] not in allowed:
            continue
        if m["id"] in notes:
            m.setdefault("metadata", {}).setdefault("designer", {})["name"] = notes[m["id"]]["name"]


def leftovers(text: str) -> set[str]:
    return {p for p in PLACEHOLDER_RE.findall(text) if p not in MAKE_SYNTAX}


def summarize(bp: dict) -> list[str]:
    lines: list[str] = []

    def walk(flow, depth=0):
        for m in flow:
            name = m.get("metadata", {}).get("designer", {}).get("name")
            lines.append("  " * depth + f"[{m['id']}] {m['module']} v{m['version']}" + (f'  "{name}"' if name else ""))
            for i, r in enumerate(m.get("routes", []) or [], 1):
                lines.append("  " * depth + f"  route {i}:")
                walk(r.get("flow", []), depth + 2)

    walk(bp["flow"])
    return lines


def check(path: Path) -> int:
    text = path.read_text(encoding="utf-8")
    bp = json.loads(text)
    print(f"Scenario name: {bp.get('name')}\nModules:")
    for line in summarize(bp):
        print("  " + line)
    left = leftovers(text)
    if left:
        print("\nFAIL: placeholders still present: " + ", ".join(sorted(left)))
        return 1
    print("\nOK: no placeholders left.")
    return 0


def s(v: str) -> str:
    return json.dumps(v, ensure_ascii=False)[1:-1]


def build_main(a: argparse.Namespace) -> int:
    text = TEMPLATE.read_text(encoding="utf-8")
    for ph, val in (("__SHEETS_CONNECTION_ID__", a.sheets_connection_id),
                    ("__CALENDLY_CONNECTION_ID__", a.calendly_connection_id),
                    ("__CALENDLY_HOOK_ID__", a.hook_id)):
        text = text.replace(f'"{ph}"', str(int(val)))
    if not re.fullmatch(r"[A-Za-z0-9_-]{20,}", a.spreadsheet_id):
        raise SystemExit("--spreadsheet-id looks wrong: use the ID from the sheet URL (between /d/ and /edit)")
    if "/" not in a.timezone:
        raise SystemExit("--timezone must be an IANA name such as America/Chicago or Europe/London")
    text = (text.replace("__SPREADSHEET_ID__", s(a.spreadsheet_id))
                .replace("__TIMEZONE__", s(a.timezone))
                .replace("__SCENARIO_NAME__", s(a.name))
                .replace("__ZONE__", s(a.zone)))
    bp = json.loads(text)
    verify_columns(bp)
    if a.stage is not None:
        apply_stage(bp, a.stage)
        apply_names(bp, None if a.name_all else a.stage - 1)
    else:
        apply_names(bp, None)
    verify_references(bp)
    out = Path(a.out)
    out.write_text(json.dumps(bp, indent=2, ensure_ascii=False), encoding="utf-8")
    print(f"Wrote {out}")
    return check(out)


def build_setup(a: argparse.Namespace) -> int:
    schema = load_schema()
    title = a.title or schema["spreadsheet_title"]
    tabs = schema["tabs"]
    body = {
        "valueInputOption": "RAW",
        "data": [{"range": f"'{t['name']}'!A1", "values": [t["headers"]]} for t in tabs],
    }
    conn = int(a.sheets_connection_id)
    bp = {
        "name": "Setup: create the Calendly Bookings spreadsheet (run once)",
        "flow": [
            {
                "id": 1, "module": "google-sheets:createSpreadsheet", "version": 2,
                "parameters": {"__IMTCONN__": conn},
                "mapper": {"properties": {"title": title},
                           "sheets": [{"properties": {"title": t["name"]}} for t in tabs]},
                "metadata": {"designer": {"x": 0, "y": 0, "name": "Create the spreadsheet"}},
            },
            {
                "id": 2, "module": "google-sheets:makeAPICall", "version": 2,
                "parameters": {"__IMTCONN__": conn},
                "mapper": {"url": "spreadsheets/{{1.spreadsheetId}}/values:batchUpdate", "method": "POST",
                           "headers": [{"key": "Content-Type", "value": "application/json"}],
                           "qs": [], "body": json.dumps(body, ensure_ascii=False)},
                "metadata": {"designer": {"x": 300, "y": 0, "name": "Write the header rows"}},
            },
        ],
        "metadata": {"instant": False, "version": 1, "zone": a.zone,
                     "scenario": {"roundtrips": 1, "maxErrors": 3, "autoCommit": True, "autoCommitTriggerLast": True,
                                  "sequential": False, "confidential": False, "dataloss": False, "dlq": False,
                                  "freshVariables": False}},
    }
    out = Path(a.out or "calendly-setup.blueprint.json")
    out.write_text(json.dumps(bp, indent=2, ensure_ascii=False), encoding="utf-8")
    print(f"Wrote {out}")
    return check(out)


def main() -> int:
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--list-stages", action="store_true")
    p.add_argument("--stage-notes", type=int, metavar="N")
    p.add_argument("--headers", action="store_true")
    p.add_argument("--headers-json", action="store_true")
    p.add_argument("--check", metavar="FILE")
    p.add_argument("--setup", action="store_true", help="build the one-time spreadsheet setup scenario")
    p.add_argument("--title", help="spreadsheet title for --setup (default from data-model.json)")
    p.add_argument("--stage", type=int)
    p.add_argument("--name-all", action="store_true")
    p.add_argument("--sheets-connection-id")
    p.add_argument("--calendly-connection-id")
    p.add_argument("--hook-id")
    p.add_argument("--spreadsheet-id")
    p.add_argument("--timezone")
    p.add_argument("--zone")
    p.add_argument("--name", default=DEFAULT_NAME)
    p.add_argument("--out")
    a = p.parse_args()

    if a.list_stages:
        for n, title, _ids, _r in STAGES:
            print(f"Stage {n}: {title}\n         adds module(s) {', '.join(map(str, stage_module_ids(n)))}")
        return 0
    if a.stage_notes is not None:
        notes = load_notes()
        print(json.dumps([{"id": i, **notes[i]} for i in stage_module_ids(a.stage_notes)], indent=2, ensure_ascii=False))
        return 0
    if a.headers:
        for t in load_schema()["tabs"]:
            print(f"{t['name']}: " + " | ".join(t["headers"]))
        return 0
    if a.headers_json:
        sch = load_schema()
        print(json.dumps({"title": a.title or sch["spreadsheet_title"], "tabs": sch["tabs"]}, indent=2, ensure_ascii=False))
        return 0
    if a.check:
        return check(Path(a.check))
    if a.setup:
        if not (a.sheets_connection_id and a.zone):
            p.error("--setup needs --sheets-connection-id and --zone")
        return build_setup(a)
    missing = [n for n in ("sheets_connection_id", "calendly_connection_id", "hook_id", "spreadsheet_id", "timezone", "zone")
               if not getattr(a, n)]
    if missing:
        p.error("missing: " + ", ".join("--" + m.replace("_", "-") for m in missing))
    a.out = a.out or "calendly-sheets.blueprint.json"
    return build_main(a)


if __name__ == "__main__":
    sys.exit(main())
