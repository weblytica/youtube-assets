# Workflow: Calendly bookings to Google Sheets (or another system)

A co-build of Andy O'Neil's "Master Calendly Events to Google Sheets" scenario. Every time someone books or cancels on the user's Calendly, Make writes the booking into four tabs of a spreadsheet: **Users**, **Event Types**, **Scheduled Events**, and **Invitees**. Each tab is kept free of duplicates: the scenario searches for the row first, then adds it or updates it in place. Cancellations update the existing rows.

Read `../../references/co-building.md` before stage 1. It holds the six beats every stage follows (Say, Add, Show, Note, Rename, Check in) and the editor mechanics. Tool order and fallbacks are in `../../references/make-mcp-playbook.md`.

## What gets built

```
Calendly: Watch events (instant webhook: invitee.created, invitee.canceled)
  → Calendly API: Get User (/users/me)
  → Calendly API: Get Scheduled Event (the meeting itself)
  → Router "Send to 4 tabs"
      ├─ Users:            Search → Router → Add row | Update row
      ├─ Event Types:      Search → Router → Add row | Update row
      ├─ Scheduled Events: Search → Router → Add row | Update row
      └─ Invitees:         Search → Parse phone (error handler: Resume) → Router → Add row | Update row
```

Files:
- `assets/calendly-sheets.template.json`: the scenario, with placeholders for connections, webhook, spreadsheet, time zone, zone, and name.
- `assets/data-model.json`: the four entities, their fields in column order, and the Make expression for each field. This file is destination-neutral; it drives the spreadsheet headers and any non-Sheets adaptation.
- `assets/module-notes.json`: display name, Make label, and note for every module (22 including the error handler).
- `scripts/build_blueprint.py`: builds the setup scenario (`--setup`), each stage (`--stage N`), or the whole thing. `--stage-notes N`, `--list-stages`, `--headers`, `--check FILE`. It refuses to emit a blueprint with a placeholder left, a mapping to a missing module, or a column count that doesn't match the tab's headers.

## Requirements to state up front

- A Make account (Free works: every module here is a standard app).
- A Calendly account connected to Make. Make's Calendly trigger subscribes to Calendly webhooks. **I am not certain which Calendly plans allow webhook subscriptions; tell the user to check Calendly's current plan page if the webhook step fails with a permission or plan error.**
- A Google account for the spreadsheet (connection type `google`, scopes spreadsheets + drive).
- Operations: about 14 per booking (trigger, 2 API calls, routers, 4 searches, 1 phone parse, 4 writes). Say "roughly", and let them check their plan.

## Setup questions (one message)

1. Which Google account should own the spreadsheet?
2. Which Calendly account (if more than one connection exists)?
3. Your time zone for the dates in the sheet? (IANA name, e.g. America/Chicago. Offer to infer from their city.)
4. Spreadsheet name? Default: "Calendly Bookings".
5. Google Sheets, or another system? If another, see **Other destinations** before going further.

Then offer: "Walk through it in six short steps (recommended), or build it all at once?"

## Phase A: Connections

Teach: a connection is a saved login Make uses to act as you.

1. `connection-requirements_get` with `calendly` v2 `watchInvitees` and `makeApiCall`, and `google-sheets` v2 `filterRows`, `addRow`, `updateRow`, `createSpreadsheet`, `makeAPICall`. Usable = listed under `existing` for every slot of that app.
2. Present the usable connections by name; the user picks. Never auto-pick.
3. Missing one: `credential-requests_create` if the tool exists (Calendly type `calendly2`, Google type `google` with the two scopes); otherwise the user adds it at `https://<zone>/<teamId>/connections` → Add. Re-check after.

## Phase B: Create the spreadsheet (Claude does this; the user just opens the link)

Teach: "Instead of you building a sheet and typing 50 headers, I'll create it in your Google Drive with every tab and header in place."

Get the layout: `python3 <skill>/workflows/calendly-sheets/scripts/build_blueprint.py --headers-json` prints the title and each tab's header row as JSON. Confirm with the user before creating anything: it adds a file to their Google Drive.

### Route 1 (preferred): Claude creates it directly

Use this when the session has a tool that can **create** a Google Sheet and **write** cell values: a Google Sheets, Google Drive, or Google Workspace connector or MCP server. Search for one with ToolSearch (for example "spreadsheet create", "google sheets", "drive create file") and read the tool descriptions; a connector that only searches or reads Drive files does not count. Don't guess tool names or parameters.

1. **Same Google account.** The sheet must belong to (or be shared with editor access to) the Google account behind the Make Google connection picked in Phase A. Ask which account the connector is signed in to, or read it from the tool if it tells you. If they differ, either share the sheet with the Make connection's account as an editor, or use Route 2.
2. Create the spreadsheet with the title, then make four tabs named exactly as in `--headers-json` (rename the default first tab rather than leaving an empty one), and write each tab's header row starting at A1.
3. Read it back (list the tabs and row 1 of each) and compare with `--headers-json`. Tab names and header order must match exactly.
4. Keep the spreadsheet ID (the part of the URL between `/d/` and `/edit`) for every later build. Give the user the link: "Here's your new sheet. Four tabs, headers in place, no rows yet."

If any step fails partway, tell the user what exists, and either finish it with the same tool or switch to Route 2 and delete (with their yes) or reuse the half-made file. Never leave two copies without saying so.

### Route 2 (fallback): a one-time Make setup scenario

Use this when no tool can create and write a sheet, the connector's Google account can't be matched to Make's, or Route 1 failed.

1. `python3 <skill>/workflows/calendly-sheets/scripts/build_blueprint.py --setup --sheets-connection-id <id> --zone <zone> [--title "<name>"] --out <scratch>/setup.blueprint.json`
2. `validate_blueprint_schema`, then `scenarios_create` (team, blueprint, `scheduling: {"type": "on-demand"}`).
3. Run it once (ask first): `scenarios_run` if the tool exists; otherwise click **Run once** in the editor through the browser, or ask the user to click it.
4. `executions_list` → newest → `executions_get-detail`. Module 1's output holds `spreadsheetId` and `spreadsheetUrl`. If you cannot read the output, ask the user to open the run's bubble on module 1 and paste the URL.
5. Give the user the spreadsheet link.
6. Offer to delete the setup scenario (`scenarios_delete`, only after a yes). It has done its job; keeping it risks a second copy if someone runs it again.

If the setup run fails at module 2 (headers), the spreadsheet already exists. Do not run setup again. Write the headers with a direct tool if one exists, fix and re-run module 2 alone, or have the user paste the rows (`--headers` prints them).

## Phase C: The Calendly webhook

The trigger needs a webhook ID (`__IMTHOOK__`). Make's Calendly hook (`calendly4`) is self-attaching: once created in Make, it registers itself with Calendly.

- **Preferred:** `rpc_execute` on `calendly` v2 `listOrganizations` (data: `__IMTCONN__`, `select: "list"`) to get the organization URI, then `listUsers` for the user URI. Then `hooks_create` with `typeName: "calendly4"`, `teamId`, a name like "Calendly bookings", and `data: {"__IMTCONN__": <id>, "events": ["invitee.created", "invitee.canceled"], "select": "list", "organization": "<org URI>", "user": "<user URI>"}`. **Confirm with the user before `hooks_create`:** it registers a webhook in their Calendly account. Note the returned hook ID. *Untested end to end by this skill's author; the shape matches Andy's working hook.*
- **Fallback:** build stage 1 with `--hook-id 0`, create the scenario, and ask the user to click the trigger → **Create a webhook** → pick the Calendly connection, tick Invitee created and Invitee canceled → Save. Then `scenarios_get` and read `parameters.__IMTHOOK__` from module 23; pass it as `--hook-id` for every later stage.

One webhook per scenario. If the user already has a Calendly webhook on another scenario, create a new one; don't reuse.

## Phase D: Build in stages

Command form: `python3 <skill>/workflows/calendly-sheets/scripts/build_blueprint.py --stage N <flags> --out <scratch>/calendly-stage-N.json`. Common flags: `--sheets-connection-id --calendly-connection-id --hook-id --spreadsheet-id --timezone --zone`. Stage 1 → `scenarios_create` (`scheduling: {"type": "on-demand"}`); stages 2 to 6 → `scenarios_update` with the full stage file. Names and notes per stage: `build_blueprint.py --stage-notes N` (save it to a file to feed `<skill>/scripts/add_notes.py --notes <file> --blueprint <current stage file>` on the API route).

| Stage | Adds (ID: name) | Say (anchor idea) | Show | Check in |
|---|---|---|---|---|
| 1 | 23: Watch new bookings | An instant trigger. Calendly calls Make the moment someone books or cancels; nothing polls on a timer. That's a webhook. | One Calendly circle with a lightning bolt (instant). | "Click the circle. See the webhook name and the two events, created and canceled?" |
| 2 | 2: Get User · 4: Get Scheduled Event | The trigger knows who booked, not the meeting details. Two API calls fill the gaps: the calendar owner, then the meeting itself. "Make an API call" is how you reach anything the ready-made modules don't cover. | Three circles. | "Click Get Scheduled Event. The URL uses replace() to trim the address. Say *next*." |
| 3 | 5: Send to 4 tabs · 3: Search Calendly User · 6: User: add or update? · 7: + Calendly User · 8: Update Calendly User | A router sends the same booking down four branches. Branch 1 shows the pattern all four use: search the tab, then a small fork with filters picks **add** if nothing was found or **update** if it was. That's an "upsert", and it's why the sheet never gets duplicates. | Router with one branch and a small fork. | "Hover the little filter icons on the fork's two lines. One says 'Not found: add', the other 'Found: update'." |
| 4 | 9 · 10 · 11 · 12 (Event Types) | Same pattern, second tab. Once you know one branch, you know all four. | Two branches. | "Can you spot the difference from branch 1? (Only the tab and the fields.)" |
| 5 | 13 · 14 · 15 · 16 (Scheduled Events) | Same pattern. New idea: formatDate() turns Calendly's UTC timestamps into your time zone, and the last column links to the Make run that wrote the row. | Three branches. | "Say *next* for the last branch." |
| 6 | 17 · 18 · 22 · 19 · 20 · 21 (Invitees) | Same pattern plus a phone clean-up, with an error handler: if the number is junk, Resume hands back blanks and the booking still saves. map() and join() squeeze the booking-form answers into one cell. | All four branches; a small side path under Parse Phone. | "That's the whole scenario. Ready to test it with a real booking?" |

Validate before pushing: `validate_module_configuration` for one Sheets search, add, and update the first time each appears (stage 3), and for `calendly:makeApiCall` at stage 2. All module configurations in the template validated against Make's catalog in October 2026.

## Phase E: Test

Teach: an instant trigger runs when data arrives, so the test is a real booking.

1. Confirm with the user: they'll book a meeting on their own Calendly link, then cancel it.
2. Put the scenario in listening mode: click **Run once** in the editor (through the browser, or hand that one click to the user). It waits for the webhook.
3. User books a test slot on their own scheduling page. Watch the bubbles fill in. Then open the spreadsheet together: one new row on each of the four tabs.
4. Run once again, then cancel that booking in Calendly. The Invitees and Scheduled Events rows should update in place (status canceled, cancellation reason), not duplicate.
5. `executions_list` / `executions_get-detail` on anything but success → `troubleshooting.md`.

## Phase F: Make it real

1. `scenarios_update` with `scheduling: {"type": "immediately"}` (instant scenarios run as data arrives).
2. `scenarios_activate`. Reload the editor so they see the toggle on.
3. Guide: `python3 <skill>/scripts/make_guide.py --blueprint <scratch>/calendly-sheets.blueprint.json --notes <skill>/workflows/calendly-sheets/assets/module-notes.json --scenario-url <editor URL> --title "<scenario name>" --overview-file <skill>/workflows/calendly-sheets/assets/guide-overview.md --setting "Spreadsheet=<url>" --setting "Time zone=<tz>" --setting "Runs=Instantly, on every booking and cancellation" --out <scratch>/Calendly-Sheets-Guide.md`. Deliver the file; don't paraphrase it.
4. Close with: what happens on every booking, where the sheet is, how to pause (toggle), where to look if a row is missing (History), the guide, and the hand-off line from SKILL.md.

## Other destinations

Google Sheets is the built-in, tested destination. If the user wants the bookings somewhere else (Airtable, Notion, HubSpot, a Make data store, Excel, a database), the scenario's shape stays the same and only the per-entity "search, then add or update" trio changes.

1. Read `../../vendor/make-skills/make-scenario-building/index.md` (which modules to use and why) and `../../vendor/make-skills/make-module-configuring/index.md` (how to configure and validate them) before designing the swap.
2. Keep stages 1 and 2 and the main router exactly as built by `build_blueprint.py` (build with any spreadsheet ID, then remove the Sheets modules) or build them by hand from the template.
3. For each entity in `assets/data-model.json`, find the destination's equivalents with `app-modules_list`: a search or "get by field" module, a create module, and an update module. Many apps have a single upsert module (for example "create or update a record"); prefer it and drop the inner router.
4. Map each field's `source` expression to the destination field with the same meaning. The key field (a Calendly URI) must be stored and searched on, so each entity needs a text field to hold it.
5. `connection-requirements_get` for the new modules, `validate_module_configuration` for each, then build in the same six stages so the co-build pacing survives. Write a name and note for each new module in the same style as `module-notes.json`.
6. If the destination needs its tables or bases created first, do it the way Phase B does for Sheets: directly with a connected tool if one can, otherwise a one-time setup scenario run once; then hand the user the link.
7. Say plainly that this path is adapted live, not the pre-tested blueprint, and test with a real booking and cancellation the same way.

## Teaching notes

- **Webhook vs polling**: Unsubby wakes on a schedule and asks "anything new?"; this one is called by Calendly the instant something happens. That's why there's no clock on the trigger.
- **Router with conditionless route filters**: the four branch labels (Users, Event Types, …) are filters with no conditions, used only as signposts. Every branch runs.
- **Upsert**: search, then filter on the search's bundle count (`__IMTLENGTH__`): 0 → add, more than 0 → update the row number the search returned (`__ROW_NUMBER__`).
- **Column A is the key**: every tab's first column is a Calendly URI. Users can add columns to the right, but must never reorder or delete column A.
- **What changed from Andy's original**: the Users search moved into branch 1 so all four branches share one pattern; a personal filter was removed; one Google connection is used throughout; the time zone is a setting.
