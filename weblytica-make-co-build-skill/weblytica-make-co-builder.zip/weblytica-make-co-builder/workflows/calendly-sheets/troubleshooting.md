# Troubleshooting the Calendly to Google Sheets scenario

Read `executions_get-detail` (or click the red module) before changing anything. Module IDs match the template.

## Setup scenario

| Symptom | Cause | Fix |
|---|---|---|
| Module 1 fails: 403 / insufficient permissions | Google connection lacks the drive scope | Use a connection listed under `existing` in `connection-requirements_get`, or create a fresh Google connection |
| Module 2 fails, spreadsheet exists but no headers | API call body or range problem | Don't re-run the whole setup (it would create a second file). Fix module 2, run it alone with the spreadsheet ID hard-coded, or paste the rows from `build_blueprint.py --headers` |
| Two "Calendly Bookings" files in Drive | Setup ran twice | Keep the one whose ID you built with; delete the other |

## Webhook and trigger [23]

- **hooks_create fails with plan or permission error**: Calendly webhooks may require a paid Calendly plan. Have the user check their plan. Nothing to fix in Make.
- **No run when a booking happens**: scenario is off and not in Run once mode, or the webhook belongs to another Calendly user/organization. `hooks_get` → check `data.user`/`data.organization`, `enabled: true`, and `scenarioId`.
- **Runs queue up but don't process**: scenario inactive. `hooks_get` shows `queueCount`. Activate the scenario; queued bookings process in order.
- **Duplicate webhook**: one hook per scenario. Delete stale hooks only with the user's yes.

## Calendly API calls [2], [4]

- **401 / invalid token**: Calendly connection expired. User reauthorizes it at Connections.
- **404 on Get Scheduled Event**: `23.event` was empty (some test payloads). Book a real test meeting.
- **Get User returns the connection owner, not the host**: by design. On a Calendly team account where others host meetings, the Users tab shows the connection owner; the Scheduled Events and Invitees rows are still correct.

## Searches [3], [9], [13], [17]

- **"Sheet not found"**: a tab was renamed. Tab names must be exactly Users, Event Types, Scheduled Events, Invitees.
- **Every booking adds a new row (duplicates)**: column A was moved or headers were edited so the search looks at the wrong column. Restore column A as the URI column.
- **400 "Unable to parse range"**: the spreadsheet ID is wrong. Rebuild with the ID from the sheet URL.

## Add and update rows [7, 8, 11, 12, 15, 16, 20, 21]

- **Columns land in the wrong place**: someone inserted a column in the middle. Columns must stay in the order of `data-model.json`; new columns go to the right of the last one.
- **Dates look like text or numbers**: `valueInputOption` must be `USER_ENTERED` (template default).
- **Script refuses: "maps N columns but tab has M headers"**: the template and `data-model.json` disagree. Fix the data model, not the check.

## Phone [18] and error handler [22]

- Junk phone numbers are expected; [22] Resume returns blank phone fields and the run continues. Not a defect.

## Scenario-level

- **Status 2 (warning) with Resume**: normal when [22] handled a bad number.
- **Operations higher than expected**: about 14 per booking. A cancellation runs the same path, so each booked-then-canceled meeting costs about 28.

## Still stuck?

After two fix attempts, point the user to Andy O'Neil at Weblytica, who built this scenario: **andy@weblytica.com** or **weblytica.com**. Give them the failing module number and error text to include.
