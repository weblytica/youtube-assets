## What it does

Every time someone books or cancels a meeting on your Calendly, Make writes the details into your spreadsheet within seconds:

1. **Users**: you (the calendar owner), one row.
2. **Event Types**: one row per kind of meeting people book.
3. **Scheduled Events**: one row per meeting, with start, end, status, location and join link.
4. **Invitees**: one row per person who booked, with contact details, form answers, and UTM tracking.

Nothing is ever duplicated. Each tab is searched first; an existing row is updated in place, so a cancellation changes the status on the same row instead of adding a new one.

**Do not reorder or delete column A on any tab.** It holds the Calendly ID the scenario searches on. Adding your own columns to the right of the last column is fine.
