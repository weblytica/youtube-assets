#!/usr/bin/env python3
"""Outline any Make scenario so Claude can document it: names, notes, and a guide.

Input is a blueprint JSON file. Either the raw blueprint, or the whole response
of the Make MCP `scenarios_get` tool (the script finds the `blueprint` key).
Large scenarios come back from `scenarios_get` saved to a file; point this
script at that file instead of reading it into the conversation.

Writes two files:

  <prefix>.outline.md   Human-readable map: every module in flow order with its
                        ID, Make app:module, current name, where it sits (route,
                        error handler), what feeds it, what it feeds, the filter
                        on its incoming line, the earlier modules it maps from,
                        and a short digest of its settings. Claude reads this to
                        write the notes.

  <prefix>.notes.json   Skeleton in the same shape as the built-in workflows'
                        module-notes.json: {"modules": {"<id>": {"name", "label",
                        "note", "current_name"}}}. Claude fills `name` and `note`.
                        apply_names.py, add_notes.py and make_guide.py read it.

Usage:
  python outline_scenario.py --blueprint scenario.json --prefix my-scenario
  python outline_scenario.py --blueprint scenario.json --prefix my-scenario --chunks 5
      --chunks N groups modules into teaching chunks of about N (route boundaries
      respected) and prints the chunk plan, for walking through documentation
      a few modules at a time.
"""
from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path

REF_RE = re.compile(r"\{\{[^}]*?\b(\d+)\.")

# Friendly labels for the built-in modules people meet most. Anything else is
# shown as app:module and Claude should look up the label with app-module_get.
BUILTIN_LABELS = {
    "builtin:BasicRouter": "Router",
    "builtin:BasicFeeder": "Iterator",
    "builtin:BasicAggregator": "Array aggregator",
    "builtin:Ignore": "Error handler: Ignore",
    "builtin:Resume": "Error handler: Resume",
    "builtin:Break": "Error handler: Break",
    "builtin:Commit": "Error handler: Commit",
    "builtin:Rollback": "Error handler: Rollback",
    "util:TextAggregator": "Tools: Text aggregator",
    "util:SetVariables": "Tools: Set multiple variables",
    "util:SetVariable2": "Tools: Set variable",
    "util:GetVariables": "Tools: Get multiple variables",
    "util:GetVariable2": "Tools: Get variable",
    "util:FunctionSleep": "Tools: Sleep",
    "regexp:Parser": "Text parser: Match pattern",
    "json:ParseJSON": "JSON: Parse JSON",
    "json:CreateJSON": "JSON: Create JSON",
    "http:ActionSendData": "HTTP: Make a request",
    "gateway:CustomWebHook": "Webhooks: Custom webhook",
    "gateway:WebhookRespond": "Webhooks: Webhook response",
}


def load_blueprint(path: Path) -> tuple[dict, dict]:
    """Return (blueprint, scenario_meta). Accepts raw blueprints or scenarios_get output."""
    text = path.read_text(encoding="utf-8")
    start = text.find("{")
    data = json.loads(text[start:])
    if "flow" in data:
        return data, {}
    for key in ("blueprint",):
        if key in data and "flow" in data[key]:
            return data[key], {k: v for k, v in data.items() if k != key}
    scen = data.get("scenario", {})
    if "blueprint" in scen:
        return scen["blueprint"], {k: v for k, v in scen.items() if k != "blueprint"}
    raise SystemExit("could not find a blueprint (a 'flow' list) in that file")


def walk(flow, place="Main line", parent=None, out=None):
    """Flatten the flow in visual order, recording placement and neighbours."""
    out = [] if out is None else out
    prev = parent
    for m in flow:
        out.append({"m": m, "place": place, "prev": prev})
        for i, r in enumerate(m.get("routes", []) or [], 1):
            walk(r.get("flow", []), f"{place} > Route {i} of [{m['id']}]", m["id"], out)
        for e in m.get("onerror", []) or []:
            out.append({"m": e, "place": f"Error handler on [{m['id']}]", "prev": m["id"]})
            for i, r in enumerate(e.get("routes", []) or [], 1):
                walk(r.get("flow", []), f"Error handler route {i}", e["id"], out)
        prev = m["id"]
    return out


def next_ids(flat: list[dict]) -> dict[int, list[int]]:
    nxt: dict[int, list[int]] = {}
    for row in flat:
        if row["prev"] is not None:
            nxt.setdefault(row["prev"], []).append(row["m"]["id"])
    return nxt


def digest(value, limit=160) -> str:
    s = json.dumps(value, ensure_ascii=False)
    return s if len(s) <= limit else s[: limit - 1] + "…"


def settings_digest(m: dict) -> list[str]:
    lines = []
    params = {k: v for k, v in (m.get("parameters") or {}).items() if not k.startswith("__IMT")}
    conn = (m.get("parameters") or {}).get("__IMTCONN__")
    hook = (m.get("parameters") or {}).get("__IMTHOOK__")
    if conn:
        lines.append(f"connection id {conn}")
    if hook:
        lines.append(f"webhook id {hook}")
    for k, v in list(params.items())[:6]:
        lines.append(f"{k} = {digest(v, 120)}")
    mapper = m.get("mapper") or {}
    for k, v in list(mapper.items())[:10]:
        lines.append(f"{k} = {digest(v, 140)}")
    if len(mapper) > 10:
        lines.append(f"... and {len(mapper) - 10} more mapped fields")
    return lines


def chunk_plan(flat: list[dict], size: int) -> list[list[int]]:
    chunks: list[list[int]] = []
    cur: list[int] = []
    cur_place = None
    for row in flat:
        place = row["place"].split(" > ")[0:2]
        if row["place"].startswith("Error handler on"):
            cur.append(row["m"]["id"])  # keep a handler with the module it protects
            continue
        if cur and (len(cur) >= size or (place != cur_place and len(cur) >= max(2, size // 2))):
            chunks.append(cur)
            cur = []
        cur.append(row["m"]["id"])
        cur_place = place
    if cur:
        chunks.append(cur)
    return chunks


def main() -> int:
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--blueprint", required=True)
    p.add_argument("--prefix", required=True, help="output file prefix, e.g. 'calendly-to-sheets'")
    p.add_argument("--chunks", type=int, help="print a teaching chunk plan of about N modules per chunk")
    a = p.parse_args()

    bp, meta = load_blueprint(Path(a.blueprint))
    flat = walk(bp["flow"])
    nxt = next_ids(flat)
    ids = [r["m"]["id"] for r in flat]
    if len(ids) != len(set(ids)):
        raise SystemExit("duplicate module ids in blueprint; cannot outline safely")

    lines = [f"# Outline: {bp.get('name', '(unnamed scenario)')}", ""]
    if meta:
        sched = meta.get("scheduling")
        lines += [f"- Scenario ID: {meta.get('id', '?')}  ·  Team: {meta.get('teamId', '?')}  ·  Active: {meta.get('isActive', '?')}",
                  f"- Scheduling: {digest(sched, 200) if sched else '(not in file)'}", ""]
    lines += [f"{len(flat)} modules. Order below is the order a run visits them (routes top to bottom).", ""]

    skeleton = {"_about": f"Names and notes for '{bp.get('name', '')}'. Fill `name` (short, says what the module does HERE, max about 30 characters) and `note` (purpose, plus how it relates to the modules before and after it). `current_name` is what the scenario has now.",
                "scenario_name": bp.get("name", ""), "modules": {}}
    for row in flat:
        m = row["m"]
        mid = m["id"]
        current = (m.get("metadata", {}).get("designer", {}) or {}).get("name", "")
        label = BUILTIN_LABELS.get(m["module"], m["module"])
        refs = sorted({int(n) for n in REF_RE.findall(json.dumps(m.get("mapper") or {}, ensure_ascii=False))} - {mid})
        feeder = (m.get("parameters") or {}).get("feeder")
        filt = m.get("filter")
        lines.append(f"## [{mid}] {current or '(no name)'}")
        lines.append(f"- Module: `{m['module']}` v{m.get('version')}  ·  label: {label}")
        lines.append(f"- Where: {row['place']}")
        lines.append(f"- Comes after: {row['prev'] if row['prev'] is not None else '(start of scenario)'}  ·  Leads to: {', '.join(map(str, nxt.get(mid, []))) or '(end of this line)'}")
        if feeder:
            lines.append(f"- Aggregates bundles that started at module {feeder}")
        if filt:
            lines.append(f"- Filter on the incoming line: **{filt.get('name', '(unnamed)')}** {digest(filt.get('conditions'), 200)}")
        if refs:
            lines.append(f"- Uses data from modules: {', '.join(map(str, refs))}")
        for s in settings_digest(m):
            lines.append(f"  - {s}")
        lines.append("")
        skeleton["modules"][str(mid)] = {"name": "", "label": label, "note": "", "current_name": current}

    Path(f"{a.prefix}.outline.md").write_text("\n".join(lines), encoding="utf-8")
    Path(f"{a.prefix}.notes.json").write_text(json.dumps(skeleton, indent=2, ensure_ascii=False), encoding="utf-8")
    print(f"Wrote {a.prefix}.outline.md and {a.prefix}.notes.json ({len(flat)} modules)")
    unnamed = [r["m"]["id"] for r in flat if not (r["m"].get("metadata", {}).get("designer", {}) or {}).get("name")]
    print(f"Modules without a name: {len(unnamed)} {unnamed if unnamed else ''}")
    if a.chunks:
        for i, c in enumerate(chunk_plan(flat, a.chunks), 1):
            print(f"Chunk {i}: modules {', '.join(map(str, c))}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
