#!/usr/bin/env python3
"""Write the Markdown guide for any documented Make scenario.

Used by the documentation workflow and the Calendly workflow (Unsubby keeps its
own tailored guide script in workflows/unsubby/scripts). Reads the blueprint
(for real names, IDs and structure) and a notes file (for each module's note),
plus an optional overview written for this scenario, and writes one document
the user keeps.

Usage:
  python make_guide.py --blueprint scenario.json --notes notes.json \
      --scenario-url https://us1.make.com/123/scenarios/456/edit \
      [--title "Scenario name"]            # default: the blueprint's name
      [--overview-file overview.md]        # Markdown inserted after the intro (What it does, etc.)
      [--setting "Runs=Every day at 07:00"] [--setting "Spreadsheet=https://..."]   # repeatable
      [--out Scenario-Guide.md]

The contact block at the end is fixed; do not remove it.
"""
from __future__ import annotations

import argparse
import json
import sys
from datetime import date
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from outline_scenario import BUILTIN_LABELS, load_blueprint, walk  # noqa: E402

CONTACT = """
---

For help with Make.com scenarios contact:
Andy O'Neil
andy@weblytica.com
https://weblytica.com
"""


def md_cell(s: str) -> str:
    return str(s).replace("|", "\\|").replace("\n", " ")


def main() -> int:
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--blueprint", required=True)
    p.add_argument("--notes", required=True)
    p.add_argument("--scenario-url", required=True)
    p.add_argument("--title")
    p.add_argument("--overview-file")
    p.add_argument("--setting", action="append", default=[], help='"Label=Value", repeatable')
    p.add_argument("--out", default="Scenario-Guide.md")
    a = p.parse_args()

    bp, _meta = load_blueprint(Path(a.blueprint))
    notes = json.loads(Path(a.notes).read_text(encoding="utf-8"))["modules"]
    title = a.title or bp.get("name") or "Make scenario"

    rows, sections, missing = [], [], []
    for row in walk(bp["flow"]):
        m = row["m"]
        mid = m["id"]
        entry = notes.get(str(mid), {})
        name = (m.get("metadata", {}).get("designer", {}) or {}).get("name") or entry.get("name") or m["module"]
        label = entry.get("label") or BUILTIN_LABELS.get(m["module"], m["module"])
        place = row["place"].replace("Main line > ", "")
        where = "" if place == "Main line" else f" ({place})"
        note = entry.get("note", "").strip()
        if not note:
            missing.append(mid)
            note = "No note recorded for this module."
        rows.append(f"| {mid} | {md_cell(name)} | {md_cell(label)}{md_cell(where)} |")
        sections.append(f"### {name}  \nModule ID **{mid}** · {label}{where}\n\n{note}\n")

    settings = ""
    if a.setting:
        lines = ["## Your settings", "", "| Setting | Value |", "|---|---|"]
        for s in a.setting:
            k, _, v = s.partition("=")
            lines.append(f"| {md_cell(k.strip())} | {md_cell(v.strip())} |")
        settings = "\n".join(lines) + "\n"

    overview = Path(a.overview_file).read_text(encoding="utf-8").strip() + "\n" if a.overview_file else ""
    today = date.today().strftime("%B %d, %Y")
    doc = f"""# {title}

Your guide to this scenario, written {today}.

**Open it in Make:** {a.scenario_url}

{overview}
{settings}
## Everyday use

- **Pause or resume:** open the scenario and use the on/off toggle at the top.
- **Something didn't happen:** open the scenario, then **History**. No run at the expected time means the scenario is off or the Make plan is out of operations. A run with an error shows the failing module in red.
- **Operations:** every module that runs costs one operation, so a run's cost is roughly the number of modules it passes through.
- **Changes:** ask Claude, or click a module to edit its settings. Each module's note (the badge at its top-left in the editor) says what it does.

## The modules at a glance

| ID | Name | Make module |
|---|---|---|
{chr(10).join(rows)}

The ID is the small number on each module in the editor.

## What each module does

{chr(10).join(sections)}
{CONTACT}"""
    Path(a.out).write_text(doc, encoding="utf-8")
    print(f"Wrote {a.out} ({len(rows)} modules)")
    if missing:
        print(f"WARNING: no note for module(s) {missing}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
