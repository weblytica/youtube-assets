#!/usr/bin/env python3
"""Pin module notes on any Make scenario through the Make REST API.

OPTIONAL fast route. Needs a Make API token in the environment variable
MAKE_API_TOKEN (created in Make under Profile, API access). Claude never asks
for the token in chat and never prints it. Without a token, add notes in the
editor (right-click a module, Add note); see references/co-building.md.

Make keeps notes outside the blueprint, so scenarios_update cannot create them:

  POST https://<zone>/api/v2/scenarios/<scenarioId>/notes
  body: {"moduleIds": [23], "content": "<p>...</p>", "isFilterNote": false, "metadata": {}}

The notes file is either a notes JSON with a "modules" object (module-notes.json
of a built-in workflow, or the file outline_scenario.py wrote and Claude filled),
or a JSON list like build_blueprint.py --stage-notes prints.

Usage:
  MAKE_API_TOKEN=... python add_notes.py --zone us1.make.com --scenario-id 456 --notes notes.json
      [--blueprint FILE] only modules present in this blueprint (use the CURRENT scenario,
                         e.g. a Free-plan Unsubby has no modules 34 and 35)
      [--ids 3,7,12]     only these modules
      [--dry-run]        print what would be added, call nothing
      [--force]          add even if the existing-notes listing fails (may duplicate notes)

Re-running is safe: a module that already has a note is skipped. If the list of
existing notes cannot be read, the script stops instead of risking duplicates
(override with --force). A failed note is reported and the rest continue.
"""
from __future__ import annotations

import argparse
import html
import json
import os
import sys
import urllib.error
import urllib.request
from pathlib import Path


def load_notes(path: Path) -> list[dict]:
    data = json.loads(path.read_text(encoding="utf-8"))
    if isinstance(data, list):
        return [{"id": int(n["id"]), "note": n.get("note", "")} for n in data]
    return [{"id": int(k), "note": v.get("note", "")} for k, v in data["modules"].items()]


def api(zone: str, token: str, method: str, path: str, body: dict | None = None):
    req = urllib.request.Request(
        f"https://{zone}/api/v2{path}",
        data=json.dumps(body).encode("utf-8") if body is not None else None,
        method=method,
        headers={"Authorization": f"Token {token}", "Content-Type": "application/json"},
    )
    try:
        with urllib.request.urlopen(req, timeout=30) as r:
            return json.loads(r.read().decode("utf-8") or "{}")
    except urllib.error.HTTPError as e:
        raise SystemExit(f"{method} {path} failed: HTTP {e.code} {e.read().decode('utf-8', 'replace')[:300]}")


def noted_modules(zone: str, token: str, scenario_id: int, force: bool) -> set[int]:
    try:
        data = api(zone, token, "GET", f"/scenarios/{scenario_id}/notes")
    except SystemExit as e:
        if force:
            print(f"warning: could not list existing notes ({e}); continuing because of --force")
            return set()
        raise SystemExit(f"Could not list existing notes, stopping to avoid duplicates: {e}. Use the editor route, or --force.")
    out: set[int] = set()
    for n in data.get("scenarioNotes", data.get("notes", [])) or []:
        out.update(int(m) for m in n.get("moduleIds", []) or [])
    return out


def main() -> int:
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--zone", required=True)
    p.add_argument("--scenario-id", type=int, required=True)
    p.add_argument("--notes", required=True)
    p.add_argument("--ids")
    p.add_argument("--blueprint")
    p.add_argument("--dry-run", action="store_true")
    p.add_argument("--force", action="store_true")
    a = p.parse_args()

    notes = [n for n in load_notes(Path(a.notes)) if n["note"].strip()]
    if a.ids:
        wanted = {int(x) for x in a.ids.split(",")}
        notes = [n for n in notes if n["id"] in wanted]
    if a.blueprint:
        sys.path.insert(0, str(Path(__file__).resolve().parent))
        from outline_scenario import load_blueprint, walk  # noqa: E402
        bp, _ = load_blueprint(Path(a.blueprint))
        present = {r["m"]["id"] for r in walk(bp["flow"])}
        skipped = [n["id"] for n in notes if n["id"] not in present]
        notes = [n for n in notes if n["id"] in present]
        if skipped:
            print(f"not in this scenario, skipped: {skipped}")
    if a.dry_run:
        for n in notes:
            print(f"would add {n['id']}: {n['note'][:80]}")
        return 0
    token = os.environ.get("MAKE_API_TOKEN")
    if not token:
        raise SystemExit("MAKE_API_TOKEN is not set. Add notes in the editor instead (see references/co-building.md).")
    already = noted_modules(a.zone, token, a.scenario_id, a.force)
    failed = []
    for n in notes:
        if n["id"] in already:
            print(f"skipped {n['id']} (already has a note)")
            continue
        try:
            api(a.zone, token, "POST", f"/scenarios/{a.scenario_id}/notes",
                {"moduleIds": [n["id"]], "content": "<p>" + html.escape(n["note"]) + "</p>", "isFilterNote": False, "metadata": {}})
            print(f"added {n['id']}")
        except SystemExit as e:
            print(f"FAILED {n['id']}: {e}")
            failed.append(n["id"])
    if failed:
        print(f"{len(failed)} note(s) failed: {failed}. Add those in the editor.")
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
