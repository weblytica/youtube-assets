#!/usr/bin/env python3
"""Apply display names from a notes file to a blueprint, changing nothing else.

Used by the documentation workflow to rename the modules of an existing
scenario through `scenarios_update`. Because `scenarios_update` replaces the
whole blueprint, this script proves the only differences are
`metadata.designer.name` values before you send it.

Usage:
  python apply_names.py --blueprint scenario.json --notes my-scenario.notes.json \
      --out scenario.named.json [--only-unnamed] [--ids 3,7,12]

  --only-unnamed   leave modules that already have a name alone
  --ids            rename only these module ids (comma separated)

Exit code 0 and a summary of renames; non-zero if anything other than names
would change. The input can be raw or a scenarios_get response; the output is
always the bare blueprint (what scenarios_update takes).
"""
from __future__ import annotations

import argparse
import copy
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from outline_scenario import load_blueprint  # noqa: E402


def iter_modules(flow):
    for m in flow:
        yield m
        for r in m.get("routes", []) or []:
            yield from iter_modules(r.get("flow", []))
        for e in m.get("onerror", []) or []:
            yield e
            for r in e.get("routes", []) or []:
                yield from iter_modules(r.get("flow", []))


def strip_names(bp: dict) -> dict:
    c = copy.deepcopy(bp)
    for m in iter_modules(c["flow"]):
        (m.get("metadata", {}).get("designer", {}) or {}).pop("name", None)
    return c


def main() -> int:
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--blueprint", required=True)
    p.add_argument("--notes", required=True)
    p.add_argument("--out", required=True)
    p.add_argument("--only-unnamed", action="store_true")
    p.add_argument("--ids")
    a = p.parse_args()

    bp, _meta = load_blueprint(Path(a.blueprint))
    original = copy.deepcopy(bp)
    notes = json.loads(Path(a.notes).read_text(encoding="utf-8"))["modules"]
    only = {int(x) for x in a.ids.split(",")} if a.ids else None

    changes = []
    for m in iter_modules(bp["flow"]):
        entry = notes.get(str(m["id"]))
        if not entry or not entry.get("name"):
            continue
        if only is not None and m["id"] not in only:
            continue
        designer = m.setdefault("metadata", {}).setdefault("designer", {})
        old = designer.get("name", "")
        if a.only_unnamed and old:
            continue
        new = entry["name"].strip()
        if len(new) > 40:
            raise SystemExit(f"name for module {m['id']} is {len(new)} characters; keep names short (about 30)")
        if new != old:
            designer["name"] = new
            changes.append((m["id"], old, new))

    if json.dumps(strip_names(bp), sort_keys=True) != json.dumps(strip_names(original), sort_keys=True):
        raise SystemExit("REFUSED: something other than module names would change")

    Path(a.out).write_text(json.dumps(bp, indent=2, ensure_ascii=False), encoding="utf-8")
    print(f"Wrote {a.out}: {len(changes)} rename(s), nothing else changed")
    for mid, old, new in changes:
        print(f"  [{mid}] {old or '(no name)'}  ->  {new}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
